/*************************************************
 *  Guard: PARAMS & SHEETS keys
 *************************************************/
(function bootstrapAugmentations_(){
  try {
    if (typeof SHEETS === 'undefined') { this.SHEETS = {}; }
    if (!SHEETS.ACHATS_LEDGER) SHEETS.ACHATS_LEDGER = 'ACHATS_LEDGER';
    if (!SHEETS.JOUEURS)       SHEETS.JOUEURS       = 'JOUEURS';

    if (typeof PARAM_KEYS === 'undefined') { this.PARAM_KEYS = {}; }
    if (!PARAM_KEYS.LEDGER_ENABLED)          PARAM_KEYS.LEDGER_ENABLED          = 'LEDGER_ENABLED';
    if (!PARAM_KEYS.JOUEURS_ENABLED)         PARAM_KEYS.JOUEURS_ENABLED         = 'JOUEURS_ENABLED';
    if (!PARAM_KEYS.RETRO_MEMBRES_READ_SRC)  PARAM_KEYS.RETRO_MEMBRES_READ_SRC  = 'RETRO_MEMBRES_READ_SOURCE';
    if (!PARAM_KEYS.RETRO_PHOTO_INCLUDE_COL) PARAM_KEYS.RETRO_PHOTO_INCLUDE_COL = 'RETRO_PHOTO_INCLUDE_COL';
  } catch(e) {}
})();

/*************************************************
 *  Hook d’orchestration post-import (FULL/INCR)
 *************************************************/
/**
 * A appeler à la fin d’un run (FULL/INCR) après les diffs et les règles.
 * @param {string} seasonSheetId
 * @param {Array<string>|Set<string>} touchedPassports  // [] en FULL
 * @param {{isFull?:boolean, isDryRun?:boolean}} opts
 */

function runPostImportAugmentations_(seasonSheetId, touchedPassports, opts) {
  var ss = getSeasonSpreadsheet_(seasonSheetId);
  var isFull   = !!(opts && opts.isFull);
  var isDryRun = !!(opts && opts.isDryRun);

  var ledgerOn  = String(readParam_(ss, 'LEDGER_ENABLED') || 'FALSE').toUpperCase() === 'TRUE';
  var joueursOn = String(readParam_(ss, 'JOUEURS_ENABLED')|| 'FALSE').toUpperCase() === 'TRUE';

  if (isDryRun) {
    try { appendImportLog_(ss, 'AUG_SKIP', 'DRY_RUN=TRUE'); } catch(e){}
    return;
  }

  var touchedSet = (function _toSet_(arr){
    if (!arr) return new Set();
    if (arr instanceof Set) return arr;
    if (Array.isArray(arr)) return new Set(arr.map(function(x){return String(x).trim();}));
    var out = new Set(); try { Object.keys(arr).forEach(function(k){ if (arr[k]) out.add(String(k).trim()); }); } catch(e){}
    return out;
  })(touchedPassports);

  try {
    if (ledgerOn) {
      if (isFull) {
        buildAchatsLedger_(ss);
        appendImportLog_(ss, 'LEDGER_BUILD_OK', JSON.stringify({mode:'FULL'}));
      } else {
        updateAchatsLedgerForPassports_(ss, touchedSet);
        appendImportLog_(ss, 'LEDGER_INCR_OK', JSON.stringify({mode:'INCR', count: touchedSet.size||0}));
      }
    } else {
      appendImportLog_(ss, 'LEDGER_DISABLED', '{}');
    }
  } catch (e) {
    appendImportLog_(ss, 'LEDGER_FAIL', String(e));
    throw e;
  }

  try {
    if (joueursOn) {
      if (isFull) {
        buildJoueursIndex_(ss);
        appendImportLog_(ss, 'JOUEURS_BUILD_OK', JSON.stringify({mode:'FULL'}));
      } else {
        updateJoueursForPassports_(ss, touchedSet);
        appendImportLog_(ss, 'JOUEURS_INCR_OK', JSON.stringify({mode:'INCR', count: touchedSet.size||0}));
      }
    } else {
      appendImportLog_(ss, 'JOUEURS_DISABLED', '{}');
    }
  } catch (e) {
    appendImportLog_(ss, 'JOUEURS_FAIL', String(e));
    throw e;
  }
}


function _augLog_(code, msg){
  try {
    if (typeof appendImportLog_ === 'function') appendImportLog_({ type:code, details: msg });
    else if (typeof addLogLine_ === 'function') addLogLine_(code, msg);
    else console && console.log && console.log(code, msg);
  } catch(e){}
}

function buildRetroMembresRowsSelected_(seasonSheetId){
  var ss = getSeasonSpreadsheet_(seasonSheetId);
  var src = String(readParam_(ss, PARAM_KEYS.RETRO_MEMBRES_READ_SRC) || 'LEGACY').toUpperCase();
  if (src === 'JOUEURS' && typeof buildRetroMembresRowsFromJoueurs_ === 'function') {
    if (typeof appendImportLog_ === 'function')
      appendImportLog_({ type:'RETRO_MEMBRES_SOURCE', details:{ source:'JOUEURS' } });
    return buildRetroMembresRowsFromJoueurs_(seasonSheetId);
  }
  if (typeof appendImportLog_ === 'function')
    appendImportLog_({ type:'RETRO_MEMBRES_SOURCE', details:{ source:'LEGACY' } });
  return buildRetroMembresRows(seasonSheetId);
}

function _pickSheetName_(ss, finalName, stagingName){
  try { return ss.getSheetByName(finalName) ? finalName : stagingName; }
  catch(e){ return stagingName; }
}


/** =========================
 *  ACHATS_LEDGER — FULL
 *  ========================= */
function buildAchatsLedger_(ss) {
  var saison = readParam_(ss, 'SEASON_LABEL') || '';

  // --- ignore list robuste (CSV vide => défaut; Set/Array/Object/CSV OK)
  var DEFAULT_IGNORE = 'senior,u-se,adulte,ligue';
  var ignoreCsvRaw = readParam_(ss, PARAM_KEYS.RETRO_IGNORE_FEES_CSV);
  var ignoreCsv = (ignoreCsvRaw && String(ignoreCsvRaw).trim()) ? ignoreCsvRaw : DEFAULT_IGNORE;

  function toIgnoreArr_(x){
    if (!x) return [];
    if (Array.isArray(x)) return x;
    if (typeof x === 'string') return x.split(',');
    if (x && typeof x.forEach === 'function' && x.add) { // ES6 Set
      var arr=[]; x.forEach(function(v){ arr.push(v); }); return arr;
    }
    if (typeof x === 'object') return Object.keys(x);
    return [];
  }
  var ignoreList = toIgnoreArr_(_compileCsvToSet_(ignoreCsv)).map(function(s){
    return String(s||'').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'').trim();
  });

  function matchIgnore_(name){
    var s = String(name||'').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'');
    for (var i=0;i<ignoreList.length;i++){
      var k = ignoreList[i]; if (!k) continue;
      if (s.indexOf(k) !== -1) return true;
    }
    return false;
  }

  // --- I/O
  var shInscName = _pickSheetName_(ss, SHEETS.INSCRIPTIONS_FINAL, SHEETS.INSCRIPTIONS);
  var shArtName  = _pickSheetName_(ss, SHEETS.ARTICLES_FINAL,     SHEETS.ARTICLES);
  var insc = readSheetAsObjects_(ss.getId(), shInscName);
  var art  = readSheetAsObjects_(ss.getId(), shArtName);

  appendImportLog_(ss, 'LEDGER_INPUT_SHEETS', JSON.stringify({insc:shInscName, art:shArtName}));
  appendImportLog_(ss, 'LEDGER_INPUT_ROWS',   JSON.stringify({insc:(insc.rows||[]).length, art:(art.rows||[]).length}));

  // --- helpers
  var normP = (typeof normalizePassport8_ === 'function')
    ? normalizePassport8_
    : function(p){ return (p == null || p === '') ? '' : String(p).replace(/\D/g,'').padStart(8,'0'); };

  function slugify_(s){ return String(s||'').toLowerCase()
    .normalize('NFD').replace(/[\u0300-\u036f]/g,'')
    .replace(/[^a-z0-9]+/g,'-').replace(/^-+|-+$/g,''); }

  // Tagger **local** (ne dépend pas d’une version externe)
  function deriveTagsLocal_(name){
    var raw = String(name||'');
    var s = raw.normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase(); // sans accents
    var tags = [];

    // adapté (tolère variantes/traits/d’accents supprimés)
    var isAdapt = /\badapte\b/.test(s) || /\badapte[e]?\b/.test(s) || /\badapte-/.test(s) || /\badapt[eé]/.test(raw.toLowerCase());
    if (isAdapt) tags.push('adapte');

    if (/camp de selection|selection/.test(s)) tags.push('camp_selection');
    if (/\bcamp\b/.test(s)) tags.push('camp');
    if (/\bcdp\b|centre de developpement/.test(s)) tags.push('cdp');
    if (/entra[iî]neur|coach/.test(s)) tags.push('coach');
    if (/futsal/.test(s)) tags.push('futsal');
    if (/gardien/.test(s)) tags.push('gardien');
    if (/\badulte\b|seniors?/.test(s)) tags.push('adulte');

    var m = s.match(/\bu-?\s?(\d{1,2})\b/);
    if (m){
      var u = +m[1];
      if (u<=8) tags.push('u4u8');
      else if (u<=12) tags.push('u9u12');
      else if (u<=18) tags.push('u13u18');
    }

    // NE PAS marquer "inscription_normale" si adapté
    if (/saison/.test(s) && !isAdapt) tags.push('inscription_normale');

    return tags;
  }

  function catFromTags_(tags){
    if (tags.includes('cdp')) return 'CDP';
    if (tags.includes('camp')) return 'CAMP';
    if (tags.includes('futsal')) return 'FUTSAL';
    if (tags.includes('inscription_normale')) return 'SEASON';
    if (tags.includes('coach')) return 'COACH';
    return 'OTHER';
  }
  function audienceFromTags_(tags){
    if (tags.includes('coach'))  return 'Entraîneur';
    if (tags.includes('adulte')) return 'Adulte';
    return 'Joueur';
  }
  function programBandFromTags_(tags){
    if (tags.includes('u4u8'))   return 'U4-U8';
    if (tags.includes('u9u12'))  return 'U9-U12';
    if (tags.includes('u13u18')) return 'U13-U18';
    if (tags.includes('adulte')) return 'Adulte';
    return '';
  }
  function parseMoney_(v){
    if (v == null || v === '') return 0;
    if (typeof v === 'number') return v;
    var s = String(v).replace(/\s/g,'').replace(/[^\d.,-]/g,'');
    var parts = s.split(',');
    if (parts.length > 1 && parts[parts.length-1].length === 2 && s.indexOf('.') === -1) {
      s = s.replace(/\./g,'').replace(',', '.');
    } else {
      s = s.replace(/,/g,'');
    }
    var n = Number(s); return isNaN(n) ? 0 : n;
  }
  function paymentStatus_(due, paid, rest){
    var d = parseMoney_(due), p = parseMoney_(paid);
    var r = (rest===''||rest==null) ? (d-p) : parseMoney_(rest);
    if (r <= 0 && (d>0 || p>0)) return 'Paid';
    if (p > 0 && r > 0) return 'Partial';
    return 'Unpaid';
  }
  function makePS_(p, s){ return (p?String(p).padStart(8,'0'):'') + '|' + String(s||''); }
  function makeRowHash_(obj){
    try{
      var s = JSON.stringify({p:obj['Passeport #'], t:obj['Type'], n:obj['NomFrais'], sa:obj['Saison']});
      var dig = Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256, s);
      return Utilities.base64Encode(dig);
    } catch(e){ return ''; }
  }

  // --- build
  var rows = [];

  function pushRow_(type, r){
    var p = normP(r['Passeport #'] || r['Passeport'] || ''); if (!p) return;

    var name   = r['Nom du frais'] || r['Frais'] || r['Produit'] || r['NomFrais'] || '';
    var status = _isActiveRow_(r) ? 1 : 0;

    var amtDue  = r['Montant dû'] || r['Montant du'] || r['Montant_dû'] || r['MontantDu'] || r['Due'] || '';
    var amtPaid = r['Montant payé'] || r['Montant paye'] || r['MontantPayé'] || r['MontantPaye'] || r['Paid'] || '';
    var amtRest = r['Montant dû restant'] || r['Montant restant'] || r['Restant'] || r['Due restant'] || r['DueRestant'] || r['Balance'] || '';

    var tags     = deriveTagsLocal_(name);
    var catCode  = catFromTags_(tags);
    var audience = audienceFromTags_(tags);
    var band     = programBandFromTags_(tags);
    var mapKey   = slugify_(name);
    var ps       = makePS_(p, saison);

    // IGNORE si "adulte" présent ou si match liste ignore
    var isIgn = (tags.includes('adulte') || matchIgnore_(name)) ? 1 : 0;

    var row = {
      'Passeport #'   : p,
      'Type'          : type,
      'NomFrais'      : name,
      'Status'        : status,
      'isIgnored'     : isIgn,
      'RowHash'       : r['ROW_HASH'] || r['RowHash'] || '',
      'Saison'        : saison,
      'PS'            : ps,
      'MapKey'        : mapKey,
      'Tags'          : tags.join(','),
      'CatCode'       : catCode,
      'Audience'      : audience,
      'isCoachFee'    : tags.includes('coach') ? 1 : 0,
      'ProgramBand'   : band,
      'AmountDue'     : parseMoney_(amtDue),
      'AmountPaid'    : parseMoney_(amtPaid),
      'AmountRestant' : parseMoney_(amtRest),
      'PaymentStatus' : paymentStatus_(amtDue, amtPaid, amtRest),
      'Qty'           : r['Quantité'] || r['Qty'] || 1,
      'CreatedAt'     : new Date(),
      'UpdatedAt'     : new Date()
    };
    if (!row['RowHash']) row['RowHash'] = makeRowHash_(row);

    rows.push(row);
  }

  (insc.rows||[]).forEach(function(r){ pushRow_('INSCRIPTION', r); });
  (art.rows ||[]).forEach(function(r){ pushRow_('ARTICLE',     r); });

  writeObjectsToSheet_(ss, 'ACHATS_LEDGER', rows, [
    'Passeport #','Type','NomFrais','Status','isIgnored','RowHash','Saison',
    'PS','MapKey','Tags','CatCode','Audience','isCoachFee','ProgramBand',
    'AmountDue','AmountPaid','AmountRestant','PaymentStatus','Qty',
    'CreatedAt','UpdatedAt'
  ]);
}


/** =========================================
 *  ACHATS_LEDGER — INCR (par passeports)
 *  ========================================= */
function updateAchatsLedgerForPassports_(ss, touchedPassports) {
  var saison = readParam_(ss, 'SEASON_LABEL') || '';

  // Normalise les passeports (8 chars)
  var normP = (typeof normalizePassport8_ === 'function')
    ? normalizePassport8_
    : function(p){ return (p == null || p === '') ? '' : String(p).replace(/\D/g,'').padStart(8,'0'); };


  // accepte Array, Set, objet {p:1}, etc.
  var rawSet = _toPassportSet_(touchedPassports);                  // <- ton helper existant
  var touchedSet = new Set(Array.from(rawSet).map(normP).filter(Boolean)); // normalise en 8 chars
  if (!touchedSet.size) return;

  // Ignore list (robuste: CSV vide => défaut; Set/Array/Object/CSV ok)
  var DEFAULT_IGNORE = 'senior,u-se,adulte,ligue';
  var ignoreCsvRaw = readParam_(ss, PARAM_KEYS.RETRO_IGNORE_FEES_CSV);
  var ignoreCsv = (ignoreCsvRaw && String(ignoreCsvRaw).trim()) ? ignoreCsvRaw : DEFAULT_IGNORE;

  function toIgnoreArr_(x){
    if (!x) return [];
    if (Array.isArray(x)) return x;
    if (typeof x === 'string') return x.split(',');
    if (x && typeof x.forEach === 'function' && x.add) { var a=[]; x.forEach(v=>a.push(v)); return a; }
    if (typeof x === 'object') return Object.keys(x);
    return [];
  }
  var ignoreList = toIgnoreArr_(_compileCsvToSet_(ignoreCsv)).map(s =>
    String(s||'').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'').trim()
  );
  function matchIgnore_(name){
    var s = String(name||'').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'');
    for (var i=0;i<ignoreList.length;i++){ var k=ignoreList[i]; if (k && s.indexOf(k)!==-1) return true; }
    return false;
  }

  // Tagger local (même que FULL)
  function slugify_(s){ return String(s||'').toLowerCase()
    .normalize('NFD').replace(/[\u0300-\u036f]/g,'')
    .replace(/[^a-z0-9]+/g,'-').replace(/^-+|-+$/g,''); }
  function deriveTagsLocal_(name){
    var raw=String(name||'');
    var s=raw.normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase();
    var tags=[], isAdapt = /\badapte\b/.test(s) || /\badapte[e]?\b/.test(s) || /\badapte-/.test(s) || /\badapt[eé]/.test(raw.toLowerCase());
    if (isAdapt) tags.push('adapte');
    if (/camp de selection|selection/.test(s)) tags.push('camp_selection');
    if (/\bcamp\b/.test(s)) tags.push('camp');
    if (/\bcdp\b|centre de developpement/.test(s)) tags.push('cdp');
    if (/entra[iî]neur|coach/.test(s)) tags.push('coach');
    if (/futsal/.test(s)) tags.push('futsal');
    if (/gardien/.test(s)) tags.push('gardien');
    if (/\badulte\b|seniors?/.test(s)) tags.push('adulte');
    var m = s.match(/\bu-?\s?(\d{1,2})\b/);
    if (m){ var u=+m[1]; if(u<=8) tags.push('u4u8'); else if(u<=12) tags.push('u9u12'); else if(u<=18) tags.push('u13u18'); }
    if (/saison/.test(s) && !isAdapt) tags.push('inscription_normale');
    return tags;
  }
  function catFromTags_(tags){
    if (tags.includes('cdp')) return 'CDP';
    if (tags.includes('camp')) return 'CAMP';
    if (tags.includes('futsal')) return 'FUTSAL';
    if (tags.includes('inscription_normale')) return 'SEASON';
    if (tags.includes('coach')) return 'COACH';
    return 'OTHER';
  }
  function audienceFromTags_(tags){ return tags.includes('coach') ? 'Entraîneur' : (tags.includes('adulte') ? 'Adulte' : 'Joueur'); }
  function programBandFromTags_(tags){
    if (tags.includes('u4u8')) return 'U4-U8';
    if (tags.includes('u9u12')) return 'U9-U12';
    if (tags.includes('u13u18')) return 'U13-U18';
    if (tags.includes('adulte')) return 'Adulte';
    return '';
  }
  function parseMoney_(v){
    if (v == null || v === '') return 0;
    if (typeof v === 'number') return v;
    var s = String(v).replace(/\s/g,'').replace(/[^\d.,-]/g,'');
    var parts = s.split(',');
    if (parts.length > 1 && parts[parts.length-1].length === 2 && s.indexOf('.') === -1) s = s.replace(/\./g,'').replace(',', '.');
    else s = s.replace(/,/g,'');
    var n = Number(s); return isNaN(n) ? 0 : n;
  }
  function paymentStatus_(due, paid, rest){
    var d = parseMoney_(due), p = parseMoney_(paid);
    var r = (rest===''||rest==null) ? (d-p) : parseMoney_(rest);
    if (r<=0 && (d>0 || p>0)) return 'Paid';
    if (p>0 && r>0) return 'Partial';
    return 'Unpaid';
  }
  function makePS_(p, s){ return (p?String(p).padStart(8,'0'):'') + '|' + String(s||''); }
  function makeRowHash_(obj){
    try{ var s = JSON.stringify({p:obj['Passeport #'], t:obj['Type'], n:obj['NomFrais'], sa:obj['Saison']});
      var dig = Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256, s);
      return Utilities.base64Encode(dig);
    } catch(e){ return ''; }
  }

  // Lire les sources finales
  var shInscName = _pickSheetName_(ss, SHEETS.INSCRIPTIONS_FINAL, SHEETS.INSCRIPTIONS);
  var shArtName  = _pickSheetName_(ss, SHEETS.ARTICLES_FINAL,     SHEETS.ARTICLES);
  var insc = readSheetAsObjects_(ss.getId(), shInscName);
  var art  = readSheetAsObjects_(ss.getId(), shArtName);

  // 1) Purge ciblée dans LEDGER (passeports touchés / saison courante)
  var ledger = readSheetAsObjects_(ss.getId(), 'ACHATS_LEDGER');
  var existing = ledger.rows || [];
  var kept = existing.filter(function(r){
    var p = normP(r['Passeport #']||'');
    return !(touchedSet.has(p) && r['Saison'] === saison);
  });
  writeObjectsToSheet_(ss, 'ACHATS_LEDGER', kept, [
    'Passeport #','Type','NomFrais','Status','isIgnored','RowHash','Saison',
    'PS','MapKey','Tags','CatCode','Audience','isCoachFee','ProgramBand',
    'AmountDue','AmountPaid','AmountRestant','PaymentStatus','Qty',
    'CreatedAt','UpdatedAt'
  ]);

  // 2) Rebuild pour ces passeports (depuis FINAL)
  var toAppend = [];
  function consider_(type, r){
    var p = normP(r['Passeport #']||r['Passeport']||''); if (!p || !touchedSet.has(p)) return;
    var name   = r['Nom du frais'] || r['Frais'] || r['Produit'] || r['NomFrais'] || '';
    var status = _isActiveRow_(r) ? 1 : 0;

    var amtDue  = r['Montant dû'] || r['Montant du'] || r['Montant_dû'] || r['MontantDu'] || r['Due'] || '';
    var amtPaid = r['Montant payé'] || r['Montant paye'] || r['MontantPayé'] || r['MontantPaye'] || r['Paid'] || '';
    var amtRest = r['Montant dû restant'] || r['Montant restant'] || r['Restant'] || r['Due restant'] || r['DueRestant'] || r['Balance'] || '';

    var tags     = deriveTagsLocal_(name);
    var isIgn    = (tags.includes('adulte') || matchIgnore_(name)) ? 1 : 0;

    var row = {
      'Passeport #'   : p,
      'Type'          : type,
      'NomFrais'      : name,
      'Status'        : status,
      'isIgnored'     : isIgn,
      'RowHash'       : r['ROW_HASH'] || r['RowHash'] || '',
      'Saison'        : saison,
      'PS'            : makePS_(p, saison),
      'MapKey'        : slugify_(name),
      'Tags'          : tags.join(','),
      'CatCode'       : catFromTags_(tags),
      'Audience'      : audienceFromTags_(tags),
      'isCoachFee'    : tags.includes('coach') ? 1 : 0,
      'ProgramBand'   : programBandFromTags_(tags),
      'AmountDue'     : parseMoney_(amtDue),
      'AmountPaid'    : parseMoney_(amtPaid),
      'AmountRestant' : parseMoney_(amtRest),
      'PaymentStatus' : paymentStatus_(amtDue, amtPaid, amtRest),
      'Qty'           : r['Quantité'] || r['Qty'] || 1,
      'CreatedAt'     : new Date(),
      'UpdatedAt'     : new Date()
    };
    if (!row['RowHash']) row['RowHash'] = makeRowHash_(row);
    toAppend.push(row);
  }
  (insc.rows||[]).forEach(function(r){ consider_('INSCRIPTION', r); });
  (art.rows ||[]).forEach(function(r){ consider_('ARTICLE',     r); });

  if (toAppend.length) appendObjectsToSheet_(ss, 'ACHATS_LEDGER', toAppend);
}

/** =========================
 *  JOUEURS — FULL
 *  ========================= */
function buildJoueursIndex_(ss) {
  var saison   = readParam_(ss, 'SEASON_LABEL') || '';
  var adapteCsv = readParam_(ss, PARAM_KEYS.RETRO_ADAPTE_KEYWORDS) || 'adapté,adapte,adapte';
  var rxAdapte = _compileKeywordsToRegex_(adapteCsv);

  var normP = (typeof normalizePassport8_ === 'function')
    ? normalizePassport8_
    : function(p){ return (p == null || p === '') ? '' : String(p).replace(/\D/g,'').padStart(8,'0'); };

  function makePS_(p, s){ return (p?String(p).padStart(8,'0'):'') + '|' + String(s||''); }

  function pickPrimaryEmail_(emailsStr){
    var arr = String(emailsStr||'').split(/[;,]/).map(function(s){return s.trim();}).filter(Boolean);
    var bad = /noreply|no-reply|invalid|test|example/i;
    for (var i=0;i<arr.length;i++){ if (!bad.test(arr[i])) return arr[i]; }
    return arr[0] || '';
  }

  function pickAgeBracketFromLedgerRows_(rows){
    var set = {};
    for (var i=0;i<rows.length;i++){ var b=rows[i].ProgramBand||''; if (b) set[b]=1; }
    if (set['U4-U8'])  return 'U4-U8';
    if (set['U9-U12']) return 'U9-U12';
    if (set['U13-U18'])return 'U13-U18';
    if (set['Adulte']) return 'Adulte';
    return '';
  }

  function computePhotoStatusByYear_(d, ageBracket, isAdapte){
    if (isAdapte || ageBracket === 'U4-U8' || ageBracket === 'Adulte') return 'Non requis';
    if (!d) return 'Aucune photo';
    try{
      var dt = (d instanceof Date) ? d : new Date(d);
      var y = (new Date()).getFullYear();
      var cutoff = new Date(y,11,31,23,59,59,999);
      return (dt >= cutoff) ? 'Photo valide' : 'Photo expirée';
    }catch(e){ return 'Aucune photo'; }
  }

  // --- I/O
  var shInscName = _pickSheetName_(ss, SHEETS.INSCRIPTIONS_FINAL, SHEETS.INSCRIPTIONS);
  var shArtName  = _pickSheetName_(ss, SHEETS.ARTICLES_FINAL,     SHEETS.ARTICLES);
  var ledger = readSheetAsObjects_(ss.getId(), 'ACHATS_LEDGER');
  var inscF  = readSheetAsObjects_(ss.getId(), shInscName);
  var artF   = readSheetAsObjects_(ss.getId(), shArtName);

  // --- Identité: INSCRIPTIONS_FINAL d'abord, fallback ARTICLES_FINAL (PAS MEMBRES_GLOBAL)
  var idByPass = {};
  (inscF.rows||[]).forEach(function(r){
    var p = normP(r['Passeport #'] || r['Passeport'] || ''); if (!p) return;
    if (!idByPass[p]) {
      idByPass[p] = {
        Nom   : r['Nom de famille'] || r['Nom'] || '',
        Prenom: r['Prénom'] || r['Prenom'] || '',
        DN    : r['Date de naissance'] || r['Naissance'] || '',
        Genre : r['Identité de genre'] || r['Genre'] || '',
        PhotoExpireLe: r['PhotoExpireLe'] || '',
        isAdapte: (String(r['Programme adapté']||'').match(/(oui|true|1)/i) ? 1 : 0)
      };
    }
  });
  (artF.rows||[]).forEach(function(r){
    var p = normP(r['Passeport #'] || r['Passeport'] || ''); if (!p) return;
    var id = idByPass[p];
    if (!id) {
      idByPass[p] = {
        Nom   : r['Nom de famille'] || r['Nom'] || '',
        Prenom: r['Prénom'] || r['Prenom'] || '',
        DN    : r['Date de naissance'] || r['Naissance'] || '',
        Genre : r['Identité de genre'] || r['Genre'] || '',
        PhotoExpireLe: r['PhotoExpireLe'] || '',
        isAdapte: 0
      };
    } else {
      if (!id.Nom)   id.Nom   = r['Nom de famille'] || r['Nom'] || '';
      if (!id.Prenom)id.Prenom= r['Prénom'] || r['Prenom'] || '';
      if (!id.DN)    id.DN    = r['Date de naissance'] || r['Naissance'] || '';
      if (!id.Genre) id.Genre = r['Identité de genre'] || r['Genre'] || '';
      if (!id.PhotoExpireLe) id.PhotoExpireLe = r['PhotoExpireLe'] || '';
    }
  });

  // --- Emails (même priorité: INSCRIPTIONS puis ARTICLES)
  var emailsByPass = {};
  (inscF.rows||[]).forEach(function(r){
    var p = normP(r['Passeport #'] || r['Passeport'] || ''); if (!p) return;
    var e = collectEmailsFromRow_(r, 'Courriel,Parent 1 - Courriel,Parent 2 - Courriel');
    if (e) _addEmails_(emailsByPass, p, e);
  });
  (artF.rows||[]).forEach(function(r){
    var p = normP(r['Passeport #'] || r['Passeport'] || ''); if (!p) return;
    if (!emailsByPass[p] && r['Courriel']) _addEmails_(emailsByPass, p, r['Courriel']);
  });

  // --- LEDGER actif/saison courante
  var actByP = new Map(); // flags
  var uiByP  = new Map(); // JSON (actifs)
  (ledger.rows||[]).forEach(function(r){
    if (r['Saison'] !== saison) return;
    if (Number(r['Status']) !== 1) return;
    var p = normP(r['Passeport #'] || r['Passeport'] || ''); if (!p) return;

    var nm   = r['NomFrais'] || r['Nom du frais'] || r['Frais'] || r['Produit'] || '';
    var ign  = Number(r['isIgnored'])||0;
    var tags = (r['Tags'] ? String(r['Tags']).split(',').map(function(x){return x.trim();}).filter(Boolean) : []);
    var aud  = r['Audience'] || '';
    var band = r['ProgramBand'] || '';

    // JSON UI (actifs seulement)
    var ui = uiByP.get(p); if (!ui){ ui = {insc:[], art:[]}; uiByP.set(p, ui); }
    if (String(r['Type']) === 'INSCRIPTION') ui.insc.push(nm); else ui.art.push(nm);

    // Flags: ignore = on ne le compte pas
    if (!ign) {
      var arr = actByP.get(p); if (!arr){ arr=[]; actByP.set(p, arr); }
      arr.push({Tags:tags, Audience:aud, ProgramBand:band, NomFrais:nm});
    }
  });

  // --- Union des passeports présents
  var seen = {};
  Object.keys(idByPass).forEach(function(p){ seen[p]=1; });
  Array.from(actByP.keys()).forEach(function(p){ seen[p]=1; });
  Array.from(uiByP.keys()).forEach(function(p){ seen[p]=1; });

  // --- Sortie
  var out = [];
  Object.keys(seen).forEach(function(p){
    var id = idByPass[p] || {};
    var nom   = id.Nom || '';
    var pren  = id.Prenom || '';
    var dna   = id.DN || '';
    var genre = (id.Genre||'').toString().trim(); if (genre) genre = genre.toUpperCase().charAt(0);

    var emailsAll = (emailsByPass[p] || []).join('; ');
    var primary   = pickPrimaryEmail_(emailsAll);

    var act = actByP.get(p) || [];
    var ui  = uiByP.get(p)  || {insc:[], art:[]};

    var hasInscription = act.some(function(r){ return r.Audience==='Joueur' && r.Tags.indexOf('inscription_normale')>=0; });
    var hasCamp        = act.some(function(r){ return r.Tags.indexOf('camp')>=0; });
    var isCoach        = act.some(function(r){ return r.Tags.indexOf('coach')>=0; });

    var isAdapte = id.isAdapte ? 1 : 0;
    if (!isAdapte && act.length){
      isAdapte = act.some(function(r){ return r.Tags.indexOf('adapte')>=0; }) ? 1 : 0;
      if (!isAdapte && rxAdapte){
        isAdapte = act.some(function(r){ return rxAdapte.test(r.NomFrais||''); }) ? 1 : 0;
      }
    }

    var inU9U12 = act.some(function(r){ return r.Audience==='Joueur' && r.Tags.indexOf('inscription_normale')>=0 && r.ProgramBand==='U9-U12'; });
    var cdpCount = '';
    if (inU9U12) {
      cdpCount = act.filter(function(r){ return r.ProgramBand==='U9-U12' && r.Tags.indexOf('cdp')>=0; }).length || 0;
    }

    var ageBracket = pickAgeBracketFromLedgerRows_(act);
    var photoStr   = computePhotoStatusByYear_(id.PhotoExpireLe, ageBracket, isAdapte);

    out.push({
      'Passeport #'     : p,
      'Nom'             : nom,
      'Prénom'          : pren,
      'DateNaissance'   : dna,
      'Genre'           : genre,
      'Courriels'       : emailsAll,
      'isAdapte'        : isAdapte,
      'cdpCount'        : cdpCount,
      'hasCamp'         : hasCamp ? 'Oui' : 'Non',
      'hasInscription'  : hasInscription ? 'Oui' : 'Non',
      'PhotoExpireLe'   : id.PhotoExpireLe || '',
      'PhotoStr'        : photoStr,
      'InscriptionsJSON': JSON.stringify(ui.insc),
      'ArticlesJSON'    : JSON.stringify(ui.art),
      'Saison'          : saison,
      'PS'              : makePS_(p, saison),
      'CourrielPrimaire': primary,
      'AgeBracket'      : ageBracket,
      'typeMembre'      : (isCoach ? 'Entraîneur' : (ageBracket==='Adulte' ? 'Adulte' : 'Joueur')),
      'isCoach'         : isCoach ? 1 : 0,
      'DerniereMaj'     : new Date()
    });
  });

  writeObjectsToSheet_(ss, 'JOUEURS', out, [
    'Passeport #','Nom','Prénom','DateNaissance','Genre','Courriels',
    'isAdapte','cdpCount','hasCamp','hasInscription',
    'PhotoExpireLe','PhotoStr','InscriptionsJSON','ArticlesJSON',
    'Saison','PS','CourrielPrimaire','AgeBracket','typeMembre','isCoach','DerniereMaj'
  ]);
}



/** =========================================
 *  JOUEURS — INCR (par passeports)
 *  ========================================= */
function updateJoueursForPassports_(ss, touchedPassports) {
  var saison = readParam_(ss, 'SEASON_LABEL') || '';
  var adapteCsv = readParam_(ss, PARAM_KEYS.RETRO_ADAPTE_KEYWORDS) || 'adapté,adapte,adapte';
  var rxAdapte = _compileKeywordsToRegex_(adapteCsv);

  var normP = (typeof normalizePassport8_ === 'function')
    ? normalizePassport8_
    : function(p){ return (p == null || p === '') ? '' : String(p).replace(/\D/g,'').padStart(8,'0'); };

  // Normalise les touchés

 var rawSet = _toPassportSet_(touchedPassports);
  var touchedSet = new Set(Array.from(rawSet).map(normP).filter(Boolean));
  if (!touchedSet.size) return;


  function pickPrimaryEmail_(emailsStr){
    var arr = String(emailsStr||'').split(/[;,]/).map(function(s){return s.trim();}).filter(Boolean);
    var bad = /noreply|no-reply|invalid|test|example/i;
    for (var i=0;i<arr.length;i++){ if (!bad.test(arr[i])) return arr[i]; }
    return arr[0] || '';
  }
  function pickAgeBracketFromLedgerRows_(rows){
    var set = {};
    for (var i=0;i<rows.length;i++){ var b=rows[i].ProgramBand||''; if (b) set[b]=1; }
    if (set['U4-U8'])  return 'U4-U8';
    if (set['U9-U12']) return 'U9-U12';
    if (set['U13-U18'])return 'U13-U18';
    if (set['Adulte']) return 'Adulte';
    return '';
  }
  function computePhotoStatusByYear_(d, ageBracket, isAdapte){
    if (isAdapte || ageBracket === 'U4-U8' || ageBracket === 'Adulte') return 'Non requis';
    if (!d) return 'Aucune photo';
    try{
      var dt = (d instanceof Date) ? d : new Date(d);
      var y = (new Date()).getFullYear();
      var cutoff = new Date(y,11,31,23,59,59,999);
      return (dt >= cutoff) ? 'Photo valide' : 'Photo expirée';
    }catch(e){ return 'Aucune photo'; }
  }
  function makePS_(p, s){ return (p?String(p).padStart(8,'0'):'') + '|' + String(s||''); }

  // I/O
  var ledger = readSheetAsObjects_(ss.getId(), 'ACHATS_LEDGER');

  var shInscName = _pickSheetName_(ss, SHEETS.INSCRIPTIONS_FINAL, SHEETS.INSCRIPTIONS);
  var shArtName  = _pickSheetName_(ss, SHEETS.ARTICLES_FINAL,     SHEETS.ARTICLES);
  var inscF  = readSheetAsObjects_(ss.getId(), shInscName);
  var artF   = readSheetAsObjects_(ss.getId(), shArtName);

  // Identité: INSCRIPTIONS_FINAL -> ARTICLES_FINAL
  var idByPass = {};
  (inscF.rows||[]).forEach(function(r){
    var p = normP(r['Passeport #'] || r['Passeport'] || ''); if (!p || !touchedSet.has(p)) return;
    if (!idByPass[p]) {
      idByPass[p] = {
        Nom   : r['Nom de famille'] || r['Nom'] || '',
        Prenom: r['Prénom'] || r['Prenom'] || '',
        DN    : r['Date de naissance'] || r['Naissance'] || '',
        Genre : r['Identité de genre'] || r['Genre'] || '',
        PhotoExpireLe: r['PhotoExpireLe'] || '',
        isAdapte: (String(r['Programme adapté']||'').match(/(oui|true|1)/i) ? 1 : 0)
      };
    }
  });
  (artF.rows||[]).forEach(function(r){
    var p = normP(r['Passeport #'] || r['Passeport'] || ''); if (!p || !touchedSet.has(p)) return;
    var id = idByPass[p];
    if (!id) {
      idByPass[p] = {
        Nom   : r['Nom de famille'] || r['Nom'] || '',
        Prenom: r['Prénom'] || r['Prenom'] || '',
        DN    : r['Date de naissance'] || r['Naissance'] || '',
        Genre : r['Identité de genre'] || r['Genre'] || '',
        PhotoExpireLe: r['PhotoExpireLe'] || '',
        isAdapte: 0
      };
    } else {
      if (!id.Nom)   id.Nom   = r['Nom de famille'] || r['Nom'] || '';
      if (!id.Prenom)id.Prenom= r['Prénom'] || r['Prenom'] || '';
      if (!id.DN)    id.DN    = r['Date de naissance'] || r['Naissance'] || '';
      if (!id.Genre) id.Genre = r['Identité de genre'] || r['Genre'] || '';
      if (!id.PhotoExpireLe) id.PhotoExpireLe = r['PhotoExpireLe'] || '';
    }
  });

  // LEDGER actif/saison courante pour ces passeports
  var actByP = new Map(); // flags + calculs
  var uiByP  = new Map(); // JSON actifs
  (ledger.rows||[]).forEach(function(r){
    if (r['Saison'] !== saison) return;
    if (Number(r['Status']) !== 1) return;
    var p = normP(r['Passeport #'] || r['Passeport'] || ''); if (!p || !touchedSet.has(p)) return;

    var nm   = r['NomFrais'] || r['Nom du frais'] || r['Frais'] || r['Produit'] || '';
    var ign  = Number(r['isIgnored'])||0;
    var tags = (r['Tags'] ? String(r['Tags']).split(',').map(function(x){return x.trim();}).filter(Boolean) : []);
    var aud  = r['Audience'] || '';
    var band = r['ProgramBand'] || '';

    var ui = uiByP.get(p); if (!ui){ ui = {insc:[], art:[]}; uiByP.set(p, ui); }
    if (String(r['Type']) === 'INSCRIPTION') ui.insc.push(nm); else ui.art.push(nm);

    if (!ign) {
      var arr = actByP.get(p); if (!arr){ arr=[]; actByP.set(p, arr); }
      arr.push({Tags:tags, Audience:aud, ProgramBand:band, NomFrais:nm});
    }
  });

  // Construire les nouvelles lignes JOUEURS
  var newRows = [];
  touchedSet.forEach(function(p){
    var id = idByPass[p] || {};
    var nom   = id.Nom || '';
    var pren  = id.Prenom || '';
    var dna   = id.DN || '';
    var genre = (id.Genre||'').toString().trim(); if (genre) genre = genre.toUpperCase().charAt(0);

    // emails
    var emailsAll = ''; // on reconstruit vite fait depuis INSCRIPTIONS/ARTICLES
    var emailsTmp = [];
    (inscF.rows||[]).forEach(function(r){
      var pp = normP(r['Passeport #'] || r['Passeport'] || ''); if (pp!==p) return;
      var e = collectEmailsFromRow_(r, 'Courriel,Parent 1 - Courriel,Parent 2 - Courriel');
      if (e) e.split(',').forEach(function(x){ x=x.trim(); if (x && emailsTmp.indexOf(x)===-1) emailsTmp.push(x); });
    });
    (artF.rows||[]).forEach(function(r){
      var pp = normP(r['Passeport #'] || r['Passeport'] || ''); if (pp!==p) return;
      var e = r['Courriel']; if (e) e.split(',').forEach(function(x){ x=x.trim(); if (x && emailsTmp.indexOf(x)===-1) emailsTmp.push(x); });
    });
    emailsAll = emailsTmp.join('; ');
    var primary = pickPrimaryEmail_(emailsAll);

    var act = actByP.get(p) || [];
    var ui  = uiByP.get(p)  || {insc:[], art:[]};

    var hasInscription = act.some(function(r){ return r.Audience==='Joueur' && r.Tags.indexOf('inscription_normale')>=0; });
    var hasCamp        = act.some(function(r){ return r.Tags.indexOf('camp')>=0; });
    var isCoach        = act.some(function(r){ return r.Tags.indexOf('coach')>=0; });

    var isAdapte = id.isAdapte ? 1 : 0;
    if (!isAdapte && act.length){
      isAdapte = act.some(function(r){ return r.Tags.indexOf('adapte')>=0; }) ? 1 : 0;
      if (!isAdapte && rxAdapte){
        isAdapte = act.some(function(r){ return rxAdapte.test(r.NomFrais||''); }) ? 1 : 0;
      }
    }

    var inU9U12 = act.some(function(r){ return r.Audience==='Joueur' && r.Tags.indexOf('inscription_normale')>=0 && r.ProgramBand==='U9-U12'; });
    var cdpCount = '';
    if (inU9U12) {
      cdpCount = act.filter(function(r){ return r.ProgramBand==='U9-U12' && r.Tags.indexOf('cdp')>=0; }).length || 0;
    }

    var ageBracket = pickAgeBracketFromLedgerRows_(act);
    var photoStr   = computePhotoStatusByYear_(id.PhotoExpireLe, ageBracket, isAdapte);

    newRows.push({
      'Passeport #'     : p,
      'Nom'             : nom,
      'Prénom'          : pren,
      'DateNaissance'   : dna,
      'Genre'           : genre,
      'Courriels'       : emailsAll,
      'isAdapte'        : isAdapte,
      'cdpCount'        : cdpCount,
      'hasCamp'         : hasCamp ? 'Oui' : 'Non',
      'hasInscription'  : hasInscription ? 'Oui' : 'Non',
      'PhotoExpireLe'   : id.PhotoExpireLe || '',
      'PhotoStr'        : photoStr,
      'InscriptionsJSON': JSON.stringify(ui.insc),
      'ArticlesJSON'    : JSON.stringify(ui.art),
      'Saison'          : saison,
      'PS'              : makePS_(p, saison),
      'CourrielPrimaire': primary,
      'AgeBracket'      : ageBracket,
      'typeMembre'      : (isCoach ? 'Entraîneur' : (ageBracket==='Adulte' ? 'Adulte' : 'Joueur')),
      'isCoach'         : isCoach ? 1 : 0,
      'DerniereMaj'     : new Date()
    });
  });

  // Upsert léger : purge lignes touchées, puis append
  var joueurs = readSheetAsObjects_(ss.getId(), 'JOUEURS');
  var existing = joueurs.rows || [];
  var kept = existing.filter(function(r){
    var p = normP(r['Passeport #']||'');
    return !touchedSet.has(p);
  });
  writeObjectsToSheet_(ss, 'JOUEURS', kept, [
    'Passeport #','Nom','Prénom','DateNaissance','Genre','Courriels',
    'isAdapte','cdpCount','hasCamp','hasInscription',
    'PhotoExpireLe','PhotoStr','InscriptionsJSON','ArticlesJSON',
    'Saison','PS','CourrielPrimaire','AgeBracket','typeMembre','isCoach','DerniereMaj'
  ]);
  if (newRows.length) appendObjectsToSheet_(ss, 'JOUEURS', newRows);
}

/* ==================
 * Helpers locaux
 * ================== */
function _compileCsvToSet_(csv){
  return new Set(String(csv||'').split(',').map(function(s){return s.trim().toLowerCase();}).filter(Boolean));
}
function _compileKeywordsToRegex_(csv){
  var arr = String(csv||'').split(',').map(function(s){return s.trim();}).filter(Boolean);
  if (!arr.length) return null;
  var esc = arr.map(function(s){return s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');});
  return new RegExp('(?:^|\\b)('+esc.join('|')+')(?:\\b|$)','i');
}
function _feeIgnoredLocal_(name, ignoreSet){
  var key = _feeKey_(name);
  return ignoreSet.has(key);
}
function _feeKey_(name){
  return String(name||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'')
               .toLowerCase().replace(/\s+/g,' ').trim();
}
function _toPassportSet_(arrOrSet){
  if (!arrOrSet) return new Set();
  if (arrOrSet instanceof Set) return arrOrSet;
  if (Array.isArray(arrOrSet)) return new Set(arrOrSet.map(function(x){return String(x).trim();}));
  // objet map {p:1} ?
  var out = new Set();
  Object.keys(arrOrSet).forEach(function(k){ if (arrOrSet[k]) out.add(String(k).trim()); });
  return out;
}
function _indexBy_(rows, keyFn){
  var o = {}; (rows||[]).forEach(function(r){ var k = keyFn(r); if (k) o[k]=r; }); return o;
}
function _addEmails_(map, p, csv){
  var arr = String(csv||'').split(',').map(function(s){return s.trim();}).filter(Boolean);
  if (!map[p]) map[p] = [];
  arr.forEach(function(e){ if (map[p].indexOf(e)===-1) map[p].push(e); });
}
function _isCdpName_(name){
  var s = _feeKey_(name);
  return s.indexOf('cdp') !== -1;
}
function _cdpCountFromName_(name){
  var s = _feeKey_(name);
  if (/\b2\b/.test(s) || /2\s*entrainement/.test(s) || /2\s*entrainements/.test(s)) return 2;
  if (/\b1\b/.test(s) || /1\s*entrainement/.test(s) || /1\s*entrainements/.test(s)) return 1;
  return 1; // CDP sans chiffre explicite => au moins 1
}
/*************************************************
 *  RÈGLES — versions rapides (FULL & INCR)
 *  - S’appuie sur ACHATS_LEDGER + JOUEURS
 *  - Ecrit ERREURS en batch
 *************************************************/



/* =========================
 * Implémentation interne
 * ========================= */
function _rulesBuildErrorsFast_(ss, touchedSet){
  var saison = readParam_(ss, 'SEASON_LABEL') || '';

  // Charger Ledger & Joueurs (1 lecture chacun)
  var ledger = readSheetAsObjects_(ss.getId(), SHEETS.ACHATS_LEDGER);
  var joueurs = readSheetAsObjects_(ss.getId(), SHEETS.JOUEURS);

  var rules = _getCompiledRulesOrFallback_(ss); // ignoreFees, rxCamp, exclusifs, etc.

  // Index Joueurs (identité + flags)
  var jByPass = {};
  (joueurs.rows||[]).forEach(function(r){
    var p = String(r['Passeport #']||'').trim(); if (!p) return;
    if (touchedSet && !touchedSet.has(p)) return;
    jByPass[p] = r;
  });

  // Grouper les achats ACTIFS & NON ignorés, par passeport & type
  var activeByPass = {}; // p -> { ART:{ feeKey -> {name,count}}, INSC:{...}, anyCamp:boolean }
  (ledger.rows||[]).forEach(function(r){
    if (r['Saison'] !== saison) return;
    var p = String(r['Passeport #']||'').trim(); if (!p) return;
    if (touchedSet && !touchedSet.has(p)) return;

    var status = Number(r['Status'])||0;
    var ign = Number(r['isIgnored'])||0;
    var type = r['Type'] === 'INSCRIPTION' ? 'INSC' : 'ART';
    var name = r['NomFrais'] || '';
    var k = _feeKey_(name);

    if (!activeByPass[p]) activeByPass[p] = { ART:{}, INSC:{}, ANY_CAMP:false };

    if (status===1 && !ign) {
      var bucket = activeByPass[p][type];
      bucket[k] = bucket[k] || { name:name, count:0 };
      bucket[k].count++;

      if (rules.rxCamp && rules.rxCamp.test(name)) activeByPass[p].ANY_CAMP = true;
    }
  });

  // Construire erreurs
  var errors = [];
  var todayStr = Utilities.formatDate(new Date(), Session.getScriptTimeZone(), 'yyyy-MM-dd');

  Object.keys(activeByPass).forEach(function(p){
    var packs = activeByPass[p];
    var j = jByPass[p] || {}; // identité & flags
    var nom = j['Nom'] || '';
    var prenom = j['Prénom'] || j['Prenom'] || '';
    var display = (prenom + ' ' + nom).trim();
    var saisonLbl = saison;

    // 1) DUPLICAT (ARTICLES): même NomFrais actif >1
    Object.keys(packs.ART).forEach(function(k){
      var rec = packs.ART[k];
      if (rec.count > 1) {
        errors.push(_errRow_({
          passeport:p, nom:nom, prenom:prenom, display:display,
          category:'ARTICLES', code:'DUPLICAT', level:'warn',
          element: rec.name, message:'Article en double détecté',
          meta: { count:rec.count }, saison:saisonLbl, date:todayStr
        }));
      }
    });

    // 2) EXCLUSIVITE: >1 article actif dans le même groupe exclusif
    var countsByGroup = {};
    Object.keys(packs.ART).forEach(function(k){
      var rec = packs.ART[k];
      var grp = rules.exclusiveGroupByItem.get(k);
      if (!grp) return;
      countsByGroup[grp] = (countsByGroup[grp]||0) + 1;
    });
    Object.keys(countsByGroup).forEach(function(grp){
      if (countsByGroup[grp] > 1) {
        errors.push(_errRow_({
          passeport:p, nom:nom, prenom:prenom, display:display,
          category:'ARTICLES', code:'EXCLUSIVITE', level:'error',
          element: grp, message:'Conflit d’articles exclusifs (groupe: '+grp+')',
          meta: { group:grp, count:countsByGroup[grp] }, saison:saisonLbl, date:todayStr
        }));
      }
    });

    // 3) U13U18_CAMP_SEUL: a un camp actif mais pas d’inscription active
    var hasInscription = Object.keys(packs.INSC).length > 0;
    var hasCamp = packs.ANY_CAMP === true;
    if (hasCamp && !hasInscription) {
      // (option) si tu veux restreindre à U13–U18, décommente:
      var dna = j['DateNaissance'] || j['Naissance'] || '';
      var curY = parseSeasonYear_(saisonLbl) || (new Date()).getFullYear();
      var by = _extractBirthYearLoose_(dna);
      var age = by ? (curY - by) : 0;
      if (!age || (age >= 13 && age <= 18)) {
        errors.push(_errRow_({
          passeport:p, nom:nom, prenom:prenom, display:display,
          category:'ARTICLES', code:'U13U18_CAMP_SEUL', level:'warn',
          element: 'Camp', message:'Inscrit à un camp de sélection mais pas à la saison',
          meta: {}, saison:saisonLbl, date:todayStr
        }));
      }
    }
  });

  return {
    header: _erreursHeader_(ss),
    errors: errors,
    ledgerCount: (ledger.rows||[]).length,
    joueursCount: (joueurs.rows||[]).length
  };

}

/** Public adapters (FAST) — exposés pour le serveur */
function runEvaluateRulesFast_(ssOpt) {
  var ss = ssOpt || getSeasonSpreadsheet_(getSeasonId_());
  // FULL: touchedSet = null
  return _rulesBuildErrorsFast_(ss, null);
}

function evaluateSeasonRulesIncrFast_(passports, ssOpt) {
  var ss = ssOpt || getSeasonSpreadsheet_(getSeasonId_());
  // INCR: touchedSet = Set<string> (8 chiffres)
  var set = new Set((passports || []).map(function(p){ return String(p||'').replace(/\D/g,'').padStart(8,'0'); }));
  return _rulesBuildErrorsFast_(ss, set);
}

/* Rendez-les accessibles via LIB et global (défensif) */
try {
  if (typeof LIB !== 'undefined' && LIB) {
    LIB.runEvaluateRulesFast_ = runEvaluateRulesFast_;
    LIB.evaluateSeasonRulesIncrFast_ = evaluateSeasonRulesIncrFast_;
    // expose aussi les privés si tu veux un fallback direct :
    LIB._rulesBuildErrorsFast_ = _rulesBuildErrorsFast_;
  } else {
    // exporte vers le global Apps Script (si pas de namespace LIB)
    this.runEvaluateRulesFast_ = runEvaluateRulesFast_;
    this.evaluateSeasonRulesIncrFast_ = evaluateSeasonRulesIncrFast_;
    this._rulesBuildErrorsFast_ = _rulesBuildErrorsFast_;
  }
} catch (_e) { /* no-op */ }


/* =========================
 *  E/S ERREURS — batch
 * ========================= */
function _rulesClearErreursSheet_(ss){
  var sh = ss.getSheetByName('ERREURS') || ss.insertSheet('ERREURS');
  sh.clear(); // garde formatage; on réécrit un header cohérent
  appendImportLog_(ss, 'RULES_CLEAR_FULL', 'ERREURS reset (append=FALSE, no filter)');
}

function _rulesWriteFull_(ss, errs, header){
  writeObjectsToSheet_(ss, 'ERREURS', errs, header);
}

function _rulesUpsertForPassports_(ss, newErrs, touchedSet, header){
  var cur = readSheetAsObjects_(ss.getId(), 'ERREURS');
  var kept = (cur.rows||[]).filter(function(r){
    var p = String(r['Passeport #']||r['Passeport']||'').trim();
    return !touchedSet.has(p);
  });
  // rewrite + append
  writeObjectsToSheet_(ss, 'ERREURS', kept, cur.header || header);
  if (newErrs.length) appendObjectsToSheet_(ss, 'ERREURS', newErrs);
}

/* =========================
 *  Helpers erreurs & règles
 * ========================= */
function _erreursHeader_(ss){
  // Essaie de réutiliser l’en-tête existant si présent
  var cur = readSheetAsObjects_(ss.getId(), 'ERREURS');
  if (cur && cur.header && cur.header.length) return cur.header;
  // Sinon header par défaut (adapter si besoin à ta feuille)
  return [
    'Passeport #','Nom','Prénom','Affichage','Catégorie','Code','Niveau',
    'Saison','Élément','Message','Meta','Date'
  ];
}

function _errRow_(o){
  return {
    'Passeport #': o.passeport || '',
    'Nom': o.nom || '',
    'Prénom': o.prenom || '',
    'Affichage': o.display || '',
    'Catégorie': o.category || '',
    'Code': o.code || '',
    'Niveau': o.level || 'warn',
    'Saison': o.saison || '',
    'Élément': o.element || '',
    'Message': o.message || '',
    'Meta': JSON.stringify(o.meta || {}),
    'Date': o.date || ''
  };
}

// Tente de charger un ruleset précompilé si présent; sinon minimalistes
function _getCompiledRulesOrFallback_(ss){
  var out = {
    ignoreFees: new Set(),
    rxCamp: _compileKeywordsToRegex_(readParam_(ss, PARAM_KEYS.RETRO_CAMP_KEYWORDS) || 'camp de selection u13,camp selection u13,camp u13'),
    exclusiveGroupByItem: new Map()
  };
  try {
    if (typeof loadRetroRulesFast_ === 'function') {
      var r = loadRetroRulesFast_(ss);
      if (r.ignoreFees) out.ignoreFees = r.ignoreFees;
      if (r.rxCamp) out.rxCamp = r.rxCamp;
      if (r.exclusiveGroupByItem) out.exclusiveGroupByItem = r.exclusiveGroupByItem;
      return out;
    }
  } catch(e){}
  // Fallback exclusifs depuis MAPPING si tu as une fonction
  try {
    if (typeof loadExclusiveGroupsMapping_ === 'function') {
      var mapping = loadExclusiveGroupsMapping_(ss); // [{group:'CDP_ENTRAINEMENT', items:[...]}]
      mapping.forEach(function(g){
        (g.items||[]).forEach(function(name){
          out.exclusiveGroupByItem.set(_feeKey_(name), g.group);
        });
      });
    }
  } catch(e){}
  return out;
}
