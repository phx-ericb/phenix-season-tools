// --- Helpers "ignore frais (RÉTRO)" ---
// normalise (trim, minuscule, sans accents)
function SR_norm_(s) {
  return String(s || '')
    .trim()
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '');
}

// Accepte soit un Spreadsheet (déjà ouvert), soit un ID → renvoie toujours un Spreadsheet
function _ensureSpreadsheet_(ssOrId) {
  return (ssOrId && typeof ssOrId.getSheetByName === 'function')
    ? ssOrId
    : getSeasonSpreadsheet_(String(ssOrId || ''));
}


// Vrai si le "Nom du frais" doit être ignoré selon RETRO_IGNORE_FEES_CSV (+ RETRO_COACH_FEES_CSV)
function SR_isIgnoredFeeRetro_(ss, fee) {
  var v = SR_norm_(fee);
  if (!v) return false;

  var baseCsv  = readParam_(ss, PARAM_KEYS.RETRO_IGNORE_FEES_CSV) || '';
  var coachCsv = readParam_(ss, 'RETRO_COACH_FEES_CSV') || '';
  var toks = (baseCsv + (baseCsv&&coachCsv?',':'') + coachCsv)
    .split(',').map(SR_norm_).filter(Boolean);

  if (toks.indexOf(v) >= 0) return true;            // exact
  for (var i = 0; i < toks.length; i++)             // contains
    if (v.indexOf(toks[i]) >= 0) return true;

  // filet lexical si paramétrage incomplet
  if (/(entraineur|entra[îi]neur|coach)/i.test(String(fee || ''))) return true;

  return false;
}


function getRules(seasonId) {
  return _wrap('getRules', function(){
    var ss = getSeasonSpreadsheet_(seasonId);
    var sh = ss.getSheetByName('RETRO_RULES_JSON');
    var text = sh && sh.getLastRow()>0 ? String(sh.getRange(1,1).getValue()||'') : '';
    if (!text) {
      var p=ss.getSheetByName('PARAMS'); if (p) { var values=p.getDataRange().getValues();
        for (var i=1;i<values.length;i++) if (values[i][0]==='RETRO_RULES_JSON') { text=String(values[i][1]||''); break; }
      }
    }
    var parsed=null, ok=true, err=''; if (text && String(text).trim()) { try { parsed=JSON.parse(text);} catch(e){ ok=false; err=String(e);} }
    return _ok({ jsonText:text, parsed:parsed, parsedOk:ok, error:err });
  });
}
function setRules(seasonId, jsonText) {
  return _wrap('setRules', function(){
    try { if (jsonText && jsonText.trim()) JSON.parse(jsonText); } catch(e) { throw new Error('Invalid JSON: ' + e); }
    var sh = getSeasonSpreadsheet_(seasonId).getSheetByName('RETRO_RULES_JSON') || getSeasonSpreadsheet_(seasonId).insertSheet('RETRO_RULES_JSON');
    sh.clear(); sh.getRange(1,1).setValue(jsonText);
    return _ok(null,'Rules saved');
  });
}

// --- DROP-IN : à coller dans server_rules.js ---

// Cache 5 min (garde ton cache global si déjà présent)
var __retroRulesCacheObj = (typeof __retroRulesCacheObj !== 'undefined') ? __retroRulesCacheObj : { at:0, obj:null };

// Lis le JSON brut (PARAM d’abord, puis feuille RETRO_RULES_JSON), sinon ''.
function _SR_readRulesRaw_(ss) {
  var raw = readParam_(ss, PARAM_KEYS.RETRO_RULES_JSON) || '';
  if (!raw) {
    var shJson = ss.getSheetByName('RETRO_RULES_JSON');
    if (shJson && shJson.getLastRow() >= 1 && shJson.getLastColumn() >= 1) {
      var vals = shJson.getDataRange().getDisplayValues();
      var pieces = [];
      for (var i=0;i<vals.length;i++) for (var j=0;j<vals[i].length;j++) {
        var cell = vals[i][j]; if (cell != null && String(cell).trim() !== '') pieces.push(String(cell));
      }
      raw = pieces.join('\n');
      appendImportLog_(ss, 'RETRO_RULES_JSON_SHEET_READ', 'chars=' + raw.length);
    }
  }
  return raw;
}

// Renvoie un OBJET {inscriptions:[], articles:[], member:[]} (fallback inclus)
function SR_loadRetroRulesObj_(ss) {
  var now = Date.now();
  if (__retroRulesCacheObj.obj && (now - __retroRulesCacheObj.at) < 5*60*1000) return __retroRulesCacheObj.obj;

  var raw = _SR_readRulesRaw_(ss);
  var obj = null;

  if (raw) {
    try {
      var parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) {
        // legacy → objet
        obj = { inscriptions:[], articles:[], member:[] };
        parsed.forEach(function(r){
          var scope = (r && r.scope) || 'inscriptions';
          var copy = Object.assign({}, r); delete copy.scope;
          (obj[scope] = obj[scope] || []).push(copy);
        });
      } else if (parsed && typeof parsed === 'object') {
        obj = { inscriptions:[], articles:[], member:[] };
        ['inscriptions','articles','member'].forEach(function(k){
          if (Array.isArray(parsed[k])) obj[k] = parsed[k];
        });
      }
    } catch(e) {
      appendImportLog_(ss, 'RETRO_RULES_JSON_PARSE_FAIL', String(e));
    }
  }

  // Fallback “comportement actuel” si manquant
  if (!obj) {
    // Lis tes CSV/params existants pour ignorer coachs/adapté etc.
    var ignoreCsv = readParam_(ss, PARAM_KEYS.RETRO_IGNORE_FEES_CSV) || '';
    var coachCsv  = readParam_(ss, 'RETRO_COACH_FEES_CSV') || '';
    var adapteCsv = readParam_(ss, PARAM_KEYS.RETRO_ADAPTE_KEYWORDS) || '';

    obj = {
      inscriptions: [
        // Exclure frais ignorés & entraîneurs (CSV + filet lexical côté lib)
        { action:'ignore_row', when:[{ col:'Nom du frais', op:'contains', val: ignoreCsv }] },
        { action:'ignore_row', when:[{ col:'Nom du frais', op:'contains', val: coachCsv  }] },
        // Flag “adapté” si mot-clé trouvé
        { action:'set_member_field', field:'adapte', value:'1',
          when:[{ col:'Nom du frais', op:'contains', val: adapteCsv }] }
      ],
      articles: [],
      member: []
    };
    appendImportLog_(ss, 'RETRO_RULES_JSON_FALLBACK', 'using PARAMS-derived defaults');
  }

  __retroRulesCacheObj = { at: now, obj: obj };
  return obj;
}

// Back-compat : si du code attend encore "une liste aplatie"
function SR_loadRetroRules_(ss) {
  var o = SR_loadRetroRulesObj_(ss);
  var flat = [];
  ['inscriptions','articles','member'].forEach(function(scope){
    (o[scope]||[]).forEach(function(r){
      var copy = Object.assign({ scope: scope }, r);
      flat.push(copy);
    });
  });
  return flat;
}
/************* RÈGLES — INCR *************/
function evaluateSeasonRulesIncr(passports) {
  var ss = SpreadsheetApp.openById(getSeasonId_());
  passports = (passports || []).map(normalizePassportPlain8_).filter(Boolean);
  if (!passports.length) return { ok:true, scanned:0, written:0, deleted:0, note:'no-passports' };

  // 0) cache “run” (optionnel mais accélère fort)
  _rulesPerfCacheBegin_(ss);

  try {
    // 1) charger règles + inputs
    var rules = (typeof SR_loadRetroRulesObj_ === 'function')
      ? SR_loadRetroRulesObj_(ss)
      : (typeof SR_loadRetroRules_ === 'function' ? SR_loadRetroRules_(ss) : []);
    var set = new Set(passports);

    // 2) charger INSCRIPTIONS / ARTICLES filtrés par passeport
    var ins = _readStagingInscriptionsByPassports_(ss, set);   // [{header, rows}]
    var art = _readStagingArticlesByPassports_(ss, set);

    // 3) exécuter le moteur de règles seulement sur ces lignes
    var res = _evaluateRulesCore_({ ss:ss, rules:rules, ins:ins, art:art, targetPassports:set });
    // res = { errors: [{Passeport, Code, ...}, ...] }

    // 4) MAJ ciblée de ERREURS : delete rows des passeports → append nouvelles erreurs
    var deleted = _deleteErrorsForPassports_(ss, passports);
    var written = _appendErrors_(ss, res.errors || []); // ta fonction existante d’append batch

    return { ok:true, scanned: (ins.rowsCount||0) + (art.rowsCount||0), written: written, deleted: deleted };
  } catch(e) {
    appendImportLog_(ss, 'RULES_INCR_FAIL', String(e));
    return { ok:false, error:String(e) };
  } finally {
    _rulesPerfCacheEnd_();
  }
}

function runEvaluateRulesIncrFromLastTouched(){
  var raw = PropertiesService.getDocumentProperties().getProperty('LAST_TOUCHED_PASSPORTS') || '[]';
  var list = (raw[0]==='[' ? JSON.parse(raw) : raw.split(',')).map(String);
  return evaluateSeasonRulesIncr(list);
}

// --- helpers ciblés ---
function _deleteErrorsForPassports_(ssOrId, passports){
 var ss = _ensureSpreadsheet_(ssOrId);
  var sh = ss.getSheetByName('ERREURS');
  
  if (!sh || sh.getLastRow() < 2) return 0;

  var H  = sh.getRange(1,1,1,sh.getLastColumn()).getValues()[0];
  var cP = H.indexOf('Passeport'); if (cP < 0) return 0;

  var set = new Set((passports || []).map(normalizePassportPlain8_).filter(Boolean));

  var last = sh.getLastRow();
  var V = sh.getRange(2,1,last-1,sh.getLastColumn()).getValues();

  var toDel = [];
  for (var i=0;i<V.length;i++){
    var p = normalizePassportPlain8_(V[i][cP]);
    if (p && set.has(p)) toDel.push(2+i);
  }
  if (!toDel.length) return 0;

  toDel.sort(function(a,b){ return b-a; });
  for (var k=0;k<toDel.length;k++){ sh.deleteRow(toDel[k]); }
  return toDel.length;
}


// lecture partielle STAGING_* (filtre par passeport)
function _readStagingInscriptionsByPassports_(ss, passSet){
  var sh = ss.getSheetByName('STAGING_INSCRIPTIONS');
  if(!sh || sh.getLastRow()<2) return { header:[], rows:[], rowsCount:0 };
  var V = sh.getDataRange().getValues(), H = V[0], cP = H.indexOf('Passeport'); if(cP<0) return {header:H, rows:[], rowsCount:0};
  var rows = [];
  for (var r=1;r<V.length;r++){
    var p = normalizePassportPlain8_(V[r][cP]);
    if (p && passSet.has(p)) rows.push(V[r]);
  }
  return { header:H, rows:rows, rowsCount:rows.length };
}

function _readStagingArticlesByPassports_(ss, passSet){
  var sh = ss.getSheetByName('STAGING_ARTICLES');
  if(!sh || sh.getLastRow()<2) return { header:[], rows:[], rowsCount:0 };
  var V = sh.getDataRange().getValues(), H = V[0], cP = H.indexOf('Passeport'); if(cP<0) return {header:H, rows:[], rowsCount:0};
  var rows = [];
  for (var r=1;r<V.length;r++){
    var p = normalizePassportPlain8_(V[r][cP]);
    if (p && passSet.has(p)) rows.push(V[r]);
  }
  return { header:H, rows:rows, rowsCount:rows.length };
}

/* PERF cache très simple pour la durée du run: params, mappings, membres */
var __rulesPerfCache = null;
function _rulesPerfCacheBegin_(ss){
  __rulesPerfCache = {
    params: _readParamsAsMap_(ss),             // map {key->value}
    mappings: _readArticlesMappingAsMap_(),    // impl existante ou à écrire si besoin
    membres: _readMembresGlobalAsMap_(ss)      // { passeport -> {PhotoExpireLe, CasierExpiré, ...} }
  };
}
function _rulesPerfCacheEnd_(){ __rulesPerfCache = null; }
function _readParamsAsMap_(ss){
  var sh = ss.getSheetByName('PARAMS'); if(!sh || sh.getLastRow()<2) return {};
  var V = sh.getRange(2,1,sh.getLastRow()-1,2).getValues(), m={};
  for(var i=0;i<V.length;i++){ m[String(V[i][0]||'')] = String(V[i][1]||''); }
  return m;
}
function _readMembresGlobalAsMap_(ss){
  var sh = ss.getSheetByName('MEMBRES_GLOBAL'); if(!sh || sh.getLastRow()<2) return {};
  var V = sh.getDataRange().getValues(); var H=V[0]; var cP=H.indexOf('Passeport'); if(cP<0) return {};
  var m = {}; for (var r=1;r<V.length;r++){ var p=normalizePassportPlain8_(V[r][cP]); if(p){ m[p] = _rowToObj_(H,V[r]); } }
  return m;
}
function _rowToObj_(H, row){ var o={}; for (var i=0;i<H.length;i++) o[String(H[i]||'')] = row[i]; return o; }
