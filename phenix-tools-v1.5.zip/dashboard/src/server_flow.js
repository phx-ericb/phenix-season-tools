/* ============================== server_flow.js =============================== */



function runImportRulesExportsIncr() {
  var seasonId = getSeasonId_();
  var ctx = startImportRun_({ seasonId: seasonId, source: 'dashboard-incr' });

  try {
    var imp = runImporterDonneesSaison();                      // import
    var touched = _getTouchedPassportsArray_();                // passeports touchés

    if (touched.length) {
      var rRules = evaluateSeasonRulesIncr(touched);           // règles ciblées
      appendImportLog_({ type:'RULES_INCR_DONE', details: rRules });
    } else {
      appendImportLog_({ type:'RULES_INCR_SKIP', details: { reason:'no-passports' } });
    }

    var combined = _boolParam_('RETRO_COMBINED_XLSX', false);  // PARAMS optionnel
    var rExp = runRetroExportsIncr(touched, { combined: combined }); // exports incr
    return { ok:true, import: imp, rules: rRules || null, exports: rExp };
  } catch (e) {
    appendImportLog_({ type:'FLOW_INCR_FAIL', details: String(e) });
    return { ok:false, error:String(e) };
  } finally {
    endImportRun_(ctx);
  }
}

function _boolParam_(key, defVal) {
  var v = String(readParamValue(key) || '').trim().toLowerCase();
  if (!v) return !!defVal;
  return v === '1' || v === 'true' || v === 'yes' || v === 'oui';
}


/* Option: full flow (force complet) */
function runImportRulesExportsFull() {
  var seasonId = getSeasonId_();
  var ctx = startImportRun_({ seasonId: seasonId, source: 'dashboard-full' });

  try {
    var imp = runImporterDonneesSaison();
    var rFull = runEvaluateRules();          // full
    var mRes  = runExportRetroMembres();     // full garanti (neutralise LAST_TOUCHED)
    var gRes  = runExportRetroGroupes();     // full garanti
    return { ok:true, import:imp, rules:rFull, membres:mRes, groupes:gRes };
  } catch (e) {
    appendImportLog_({ type:'FLOW_FULL_FAIL', details: String(e) });
    return { ok:false, error:String(e) };
  } finally {
    endImportRun_(ctx);
  }
}
