/***** server_exports_entraineurs.js *****/

/** Exporte la liste des entraîneurs (membres) avec infos + photo/casier */
function exportRetroEntraineursMembresXlsxToDrive(seasonId, opts) {
const ss = SpreadsheetApp.openById(seasonId);
  const membres = _ex_fetchMembresEntraineurs_(ss, seasonId); // jointure MEMBRES_GLOBAL x ENTRAINEURS_ROLES (distinct par passeport)
  const headers = [
    'Passeport','Prenom','Nom','DateNaissance','Genre','StatutMembre',
    'PhotoExpireLe','CasierExpiré'
  ];
  const rows = membres.map(m => [
    m.Passeport, m.Prenom, m.Nom, m.DateNaissance, m.Genre, m.StatutMembre,
    m.PhotoExpireLe, m.CasierExpiré
  ]);

  return _ex_writeXlsxToDrive_(`retro-entraineurs-membres-${seasonId}.xlsx`, headers, rows, opts);
}

/** Exporte les groupes d’entraîneurs (rôles → groupes rétroaction) */
function exportRetroEntraineursGroupesXlsxToDrive(seasonId, opts) {
const ss = SpreadsheetApp.openById(seasonId);
  const roles = _ex_fetchRoles_(ss, seasonId); // raw
  const headers = ['Passeport','Type','Groupe','Commentaire'];
  // Mapping simple: Type = 'entraineur'; Groupe = concat(Role|Categorie|Equipe) ou appliquer ton MAPPING si nécessaire
  const rows = roles.map(r => {
    const type = 'entraineur';
    const groupe = `${r.Role} | ${r.Categorie} | ${r.Equipe}`.trim();
    return [r.Passeport, type, groupe, r.Commentaire || ''];
  });

  return _ex_writeXlsxToDrive_(`retro-entraineurs-groupes-${seasonId}.xlsx`, headers, rows, opts);
}

/* === Helpers === */

function _ex_fetchRoles_(ss, seasonId) {
  const sh = getSheet_(ss, 'ENTRAINEURS_ROLES', false);
  if (!sh) return [];
  const data = sh.getDataRange().getValues();
  if (data.length < 2) return [];
  const h = data[0].map(x=>String(x).trim());
  const col = {};
  h.forEach((x,i)=> col[x]=i);
  const res = [];
  for (let r=1;r<data.length;r++){
    const row = data[r];
    const saison = String(row[col['Saison']]||'').trim();
    if (!saison || saison !== seasonId) continue;
    const pass = String(row[col['Passeport']]||'').trim();
    if (!pass) continue;
    res.push({
      Passeport: pass,
      Saison: saison,
      Role: String(row[col['Role']]||'').trim(),
      Categorie: String(row[col['Categorie']]||'').trim(),
      Equipe: String(row[col['Equipe']]||'').trim(),
      Commentaire: String(row[col['Commentaire']]||'').trim()
    });
  }
  return res;
}

function _ex_fetchMembresEntraineurs_(ss, seasonId) {
  const roles = _ex_fetchRoles_(ss, seasonId);
  if (!roles.length) return [];
  const passports = Array.from(new Set(roles.map(r=>r.Passeport)));

  const sh = getSheet_(ss, readParam_(ss,'SHEET_MEMBRES_GLOBAL')||'MEMBRES_GLOBAL', true);
  const data = sh.getDataRange().getValues();
  const h = data[0].map(x=>String(x).trim());
  const col = {};
  h.forEach((x,i)=> col[x]=i);

  const idx = new Map();
  for (let r=1;r<data.length;r++){
    const pass = String(data[r][col['Passeport']]||'').trim();
    if (!pass) continue;
    idx.set(pass, data[r]);
  }

  const out = [];
  passports.forEach(p=>{
    const row = idx.get(p);
    if (!row) return;
    out.push({
      Passeport: p,
      Prenom: row[col['Prenom']]||'',
      Nom: row[col['Nom']]||'',
      DateNaissance: row[col['DateNaissance']]||'',
      Genre: row[col['Genre']]||'',
      StatutMembre: row[col['StatutMembre']]||'',
      PhotoExpireLe: row[col['PhotoExpireLe']]||'',
      CasierExpiré: row[col['CasierExpiré']]||''
    });
  });
  return out;
}

function _ex_writeXlsxToDrive_(filename, headers, rows, opts) {
  // Tu as déjà une fabrique XLSX (via SpreadsheetApp + export) — sinon, créer un ss temporaire et exporter en xlsx.
  const tmp = SpreadsheetApp.create(`TMP_${filename}`);
  const sh = tmp.getSheets()[0];
  sh.clear();
  sh.getRange(1,1,1,headers.length).setValues([headers]);
  if (rows.length) sh.getRange(2,1,rows.length,headers.length).setValues(rows);
  const blob = DriveApp.getFileById(tmp.getId()).getAs('application/vnd.openxmlformats-officedocument.spreadsheetml.sheet').setName(filename);
  const folderId = (opts && opts.folderId) || readParam_(SpreadsheetApp.getActive(), 'DRIVE_FOLDER_EXPORTS');
  const folder = folderId ? DriveApp.getFolderById(folderId) : DriveApp.getRootFolder();
  const file = folder.createFile(blob);
  DriveApp.getFileById(tmp.getId()).setTrashed(true);
  log_('EXPORT_DONE', filename);
  return {fileId: file.getId(), name: filename};
}
function getKpisBoth() {
  var seasonId = getSeasonId_();
  var ss = SpreadsheetApp.openById(seasonId);

  var seasonYear = Number(readParam_(ss, 'SEASON_YEAR') || new Date().getFullYear());
  var invalidFrom = (readParam_(ss, 'PHOTO_INVALID_FROM_MMDD') || '04-01').trim();
  var cutoffNextJan1 = (seasonYear + 1) + '-01-01';
  var dueDate = seasonYear + '-' + invalidFrom;
  var today = Utilities.formatDate(new Date(), Session.getScriptTimeZone(), 'yyyy-MM-dd');

  var shMG = ss.getSheetByName(readParam_(ss,'SHEET_MEMBRES_GLOBAL') || 'MEMBRES_GLOBAL');
  if (!shMG || shMG.getLastRow() < 2) {
    return {
      joueurs:   { photosEchues:0, photosARenouv:0, total:0 },
      entraineurs:{ photosEchues:0, photosARenouv:0, casiersExp:0, total:0 }
    };
  }

  var V = shMG.getDataRange().getValues();
  var H = V[0];
  var cPass  = H.indexOf('Passeport'),
      cPhoto = H.indexOf('PhotoExpireLe'),
      cCas   = H.indexOf('CasierExpiré'),
      cStat  = H.indexOf('StatutMembre'); // utile si tu veux filtrer “inscrit” côté fallback joueurs

  // set Joueurs (depuis la feuille finale `inscriptions`)
  var joueursSet = new Set();
  (function(){
    var shJ = ss.getSheetByName('inscriptions');
    if (shJ && shJ.getLastRow() > 1) {
      var J = shJ.getDataRange().getValues();
      var hj = J[0], jp = hj.indexOf('Passeport');
      for (var r=1;r<J.length;r++){
        var p = normalizePassportPlain8_(J[r][jp]);
        if (p) joueursSet.add(p);
      }
    }
  })();

  // set Entraîneurs (depuis ENTRAINEURS_ROLES)
  var coachSet = new Set();
  (function(){
    var shR = ss.getSheetByName('ENTRAINEURS_ROLES');
    if (shR && shR.getLastRow() > 1) {
      var R = shR.getDataRange().getValues();
      var hr = R[0], rp = hr.indexOf('Passeport');
      for (var r=1;r<R.length;r++){
        var p = normalizePassportPlain8_(R[r][rp]);
        if (p) coachSet.add(p);
      }
    }
  })();

  var kJ = { photosEchues:0, photosARenouv:0, total:0 };            // joueurs: pas de casier
  var kE = { photosEchues:0, photosARenouv:0, casiersExp:0, total:0 }; // entraîneurs: inclut casier

  for (var i=1;i<V.length;i++){
    var p = normalizePassportPlain8_(V[i][cPass]);
    if (!p) continue;

    var exp = String(V[i][cPhoto] || '');
    var inval = (exp && exp < cutoffNextJan1) ? 1 : 0;
    var due  = inval && today < dueDate;         // invalide mais “à renouveler” (avant date due)
    var echue = inval && today >= dueDate;       // invalide et due (après date due)

    // Joueurs
    if (joueursSet.size && joueursSet.has(p)) {
      kJ.total++;
      if (!exp) { // aucune photo
        if (today >= dueDate) kJ.photosEchues++; else kJ.photosARenouv++;
      } else {
        if (echue) kJ.photosEchues++;
        else if (due) kJ.photosARenouv++;
      }
    }

    // Entraîneurs
    if (coachSet.size && coachSet.has(p)) {
      kE.total++;
      var cas = Number(V[i][cCas] || 0);
      if (!exp) { // aucune photo
        if (today >= dueDate) kE.photosEchues++; else kE.photosARenouv++;
      } else {
        if (echue) kE.photosEchues++;
        else if (due) kE.photosARenouv++;
      }
      if (cas === 1) kE.casiersExp++;
    }
  }

  return { joueurs: kJ, entraineurs: kE };
}
function getJoueursPhotosProblemes() {
  var seasonId = getSeasonId_();
  var ss = SpreadsheetApp.openById(seasonId);

  var seasonYear = Number(readParam_(ss, 'SEASON_YEAR') || new Date().getFullYear());
  var invalidFrom = (readParam_(ss, 'PHOTO_INVALID_FROM_MMDD') || '04-01').trim();
  var cutoffNextJan1 = (seasonYear + 1) + '-01-01';
  var dueDate = seasonYear + '-' + invalidFrom;
  var today = Utilities.formatDate(new Date(), Session.getScriptTimeZone(), 'yyyy-MM-dd');

  var shMG = ss.getSheetByName(readParam_(ss,'SHEET_MEMBRES_GLOBAL') || 'MEMBRES_GLOBAL');
  var shJ  = ss.getSheetByName('inscriptions');
  if (!shMG || !shJ || shMG.getLastRow()<2 || shJ.getLastRow()<2) return [];

  // set des joueurs inscrits
  var J = shJ.getDataRange().getValues();
  var hj = J[0], jp = hj.indexOf('Passeport');
  var joueursSet = new Set();
  for (var r=1;r<J.length;r++){
    var p = normalizePassportPlain8_(J[r][jp]); if (p) joueursSet.add(p);
  }

  var V = shMG.getDataRange().getValues();
  var H = V[0];
  var cPass=H.indexOf('Passeport'), cNom=H.indexOf('Nom'), cPre=H.indexOf('Prenom'),
      cPh=H.indexOf('PhotoExpireLe');

  var out = [];
  for (var i=1;i<V.length;i++){
    var p = normalizePassportPlain8_(V[i][cPass]);
    if (!p || !joueursSet.has(p)) continue;

    var photo = String(V[i][cPh] || '');
    var inval = (!photo) || (photo < cutoffNextJan1);
    if (!inval) continue;

    var statut = (!photo) ? 'AUCUNE PHOTO' :
                 (today >= dueDate ? 'ÉCHUE' : ('À RENOUVELER dès ' + dueDate));

    out.push({
      Passeport: p,
      Nom: String(V[i][cNom]||''),
      Prenom: String(V[i][cPre]||''),
      PhotoExpireLe: photo || '',
      StatutPhoto: statut
    });
  }

  // tri par Nom, Prénom
  out.sort(function(a,b){
    var A=(a.Nom||'')+(a.Prenom||''); var B=(b.Nom||'')+(b.Prenom||'');
    return A.localeCompare(B,'fr');
  });
  return out;
}
