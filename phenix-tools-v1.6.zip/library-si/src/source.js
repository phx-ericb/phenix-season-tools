/*************************************************
 *  Guard: PARAMS & SHEETS keys
 *************************************************/
(function bootstrapAugmentations_(){
  try {
    if (typeof SHEETS === 'undefined') { this.SHEETS = {}; }
    if (!SHEETS.ACHATS_LEDGER) SHEETS.ACHATS_LEDGER = 'ACHATS_LEDGER';
    if (!SHEETS.JOUEURS)       SHEETS.JOUEURS       = 'JOUEURS';

    if (typeof PARAM_KEYS === 'undefined') { this.PARAM_KEYS = {}; }
    if (!PARAM_KEYS.LEDGER_ENABLED)          PARAM_KEYS.LEDGER_ENABLED          = 'LEDGER_ENABLED';
    if (!PARAM_KEYS.JOUEURS_ENABLED)         PARAM_KEYS.JOUEURS_ENABLED         = 'JOUEURS_ENABLED';
    if (!PARAM_KEYS.RETRO_MEMBRES_READ_SRC)  PARAM_KEYS.RETRO_MEMBRES_READ_SRC  = 'RETRO_MEMBRES_READ_SOURCE';
    if (!PARAM_KEYS.RETRO_PHOTO_INCLUDE_COL) PARAM_KEYS.RETRO_PHOTO_INCLUDE_COL = 'RETRO_PHOTO_INCLUDE_COL';
  } catch(e) {}
})();

/*************************************************
 *  Hook d’orchestration post-import (FULL/INCR)
 *************************************************/
/**
 * A appeler à la fin d’un run (FULL/INCR) après les diffs et les règles.
 * @param {string} seasonSheetId
 * @param {Array<string>|Set<string>} touchedPassports  // [] en FULL
 * @param {{isFull?:boolean, isDryRun?:boolean}} opts
 */

function runPostImportAugmentations_(seasonSheetId, touchedPassports, opts) {
  var ss = getSeasonSpreadsheet_(seasonSheetId);
  var isFull   = !!(opts && opts.isFull);
  var isDryRun = !!(opts && opts.isDryRun);

  var ledgerOn  = String(readParam_(ss, 'LEDGER_ENABLED') || 'FALSE').toUpperCase() === 'TRUE';
  var joueursOn = String(readParam_(ss, 'JOUEURS_ENABLED')|| 'FALSE').toUpperCase() === 'TRUE';

  if (isDryRun) {
    try { appendImportLog_(ss, 'AUG_SKIP', 'DRY_RUN=TRUE'); } catch(e){}
    return;
  }

  var touchedSet = (function _toSet_(arr){
    if (!arr) return new Set();
    if (arr instanceof Set) return arr;
    if (Array.isArray(arr)) return new Set(arr.map(function(x){return String(x).trim();}));
    var out = new Set(); try { Object.keys(arr).forEach(function(k){ if (arr[k]) out.add(String(k).trim()); }); } catch(e){}
    return out;
  })(touchedPassports);

  try {
    if (ledgerOn) {
      if (isFull) {
        buildAchatsLedger_(ss);
        appendImportLog_(ss, 'LEDGER_BUILD_OK', JSON.stringify({mode:'FULL'}));
      } else {
        updateAchatsLedgerForPassports_(ss, touchedSet);
        appendImportLog_(ss, 'LEDGER_INCR_OK', JSON.stringify({mode:'INCR', count: touchedSet.size||0}));
      }
    } else {
      appendImportLog_(ss, 'LEDGER_DISABLED', '{}');
    }
  } catch (e) {
    appendImportLog_(ss, 'LEDGER_FAIL', String(e));
    throw e;
  }

  try {
    if (joueursOn) {
      if (isFull) {
        buildJoueursIndex_(ss);
        appendImportLog_(ss, 'JOUEURS_BUILD_OK', JSON.stringify({mode:'FULL'}));
      } else {
        updateJoueursForPassports_(ss, touchedSet);
        appendImportLog_(ss, 'JOUEURS_INCR_OK', JSON.stringify({mode:'INCR', count: touchedSet.size||0}));
      }
    } else {
      appendImportLog_(ss, 'JOUEURS_DISABLED', '{}');
    }
  } catch (e) {
    appendImportLog_(ss, 'JOUEURS_FAIL', String(e));
    throw e;
  }
}


function _augLog_(code, msg){
  try {
    if (typeof appendImportLog_ === 'function') appendImportLog_({ type:code, details: msg });
    else if (typeof addLogLine_ === 'function') addLogLine_(code, msg);
    else console && console.log && console.log(code, msg);
  } catch(e){}
}

function buildRetroMembresRowsSelected_(seasonSheetId){
  var ss = getSeasonSpreadsheet_(seasonSheetId);
  var src = String(readParam_(ss, PARAM_KEYS.RETRO_MEMBRES_READ_SRC) || 'LEGACY').toUpperCase();
  if (src === 'JOUEURS' && typeof buildRetroMembresRowsFromJoueurs_ === 'function') {
    if (typeof appendImportLog_ === 'function')
      appendImportLog_({ type:'RETRO_MEMBRES_SOURCE', details:{ source:'JOUEURS' } });
    return buildRetroMembresRowsFromJoueurs_(seasonSheetId);
  }
  if (typeof appendImportLog_ === 'function')
    appendImportLog_({ type:'RETRO_MEMBRES_SOURCE', details:{ source:'LEGACY' } });
  return buildRetroMembresRows(seasonSheetId);
}

function _pickSheetName_(ss, finalName, stagingName){
  try { return ss.getSheetByName(finalName) ? finalName : stagingName; }
  catch(e){ return stagingName; }
}


/** =========================
 *  ACHATS_LEDGER — FULL
 *  ========================= */
function buildAchatsLedger_(ss) {
  var saison = readParam_(ss, 'SEASON_LABEL') || '';
  var ignoreCsv = readParam_(ss, PARAM_KEYS.RETRO_IGNORE_FEES_CSV) || 'senior,u-se,adulte,ligue';
  var ignoreSet = _compileCsvToSet_(ignoreCsv);

  // Lire FINAL si présent, sinon fallback sur les feuilles standard
var shInscName = _pickSheetName_(ss, SHEETS.INSCRIPTIONS_FINAL, SHEETS.INSCRIPTIONS);
var shArtName  = _pickSheetName_(ss, SHEETS.ARTICLES_FINAL,     SHEETS.ARTICLES);

var insc = readSheetAsObjects_(ss.getId(), shInscName);
var art  = readSheetAsObjects_(ss.getId(), shArtName);

// (diagnostic conseillé)
appendImportLog_(ss, 'LEDGER_INPUT_SHEETS', JSON.stringify({insc:shInscName, art:shArtName}));
appendImportLog_(ss, 'LEDGER_INPUT_ROWS', JSON.stringify({insc:(insc.rows||[]).length, art:(art.rows||[]).length}));

var rows = [];

  function pushRow_(type, r){
    var p = String(r['Passeport #'] || '').trim();
    if (!p) return;
    var name = r['Nom du frais'] || r['Frais'] || r['Produit'] || '';
    var status = _isActiveRow_(r) ? 1 : 0; // même critère pour INSCRIPTIONS & ARTICLES
    var isIgnored = _feeIgnoredLocal_(name, ignoreSet) ? 1 : 0;

    rows.push({
      'Passeport #': p,
      'Type': type,                              // 'INSCRIPTION' | 'ARTICLE'
      'NomFrais': name,
      'Status': status,                          // 1 actif, 0 annulé
      'isIgnored': isIgnored,                    // filtrage métier en aval
      'RowHash': r['ROW_HASH'] || '',
      'Saison': saison,
      'CreatedAt': new Date(),
      'UpdatedAt': new Date()
    });
  }

  (insc.rows||[]).forEach(function(r){ pushRow_('INSCRIPTION', r); });
  (art.rows ||[]).forEach(function(r){ pushRow_('ARTICLE',     r); });

  writeObjectsToSheet_(ss, 'ACHATS_LEDGER', rows, [
    'Passeport #','Type','NomFrais','Status','isIgnored','RowHash','Saison','CreatedAt','UpdatedAt'
  ]);
}

/** =========================================
 *  ACHATS_LEDGER — INCR (par passeports)
 *  ========================================= */
function updateAchatsLedgerForPassports_(ss, touchedPassports) {
  var saison = readParam_(ss, 'SEASON_LABEL') || '';
  var ignoreCsv = readParam_(ss, PARAM_KEYS.RETRO_IGNORE_FEES_CSV) || 'senior,u-se,adulte,ligue';
  var ignoreSet = _compileCsvToSet_(ignoreCsv);
  var touchedSet = _toPassportSet_(touchedPassports);

  if (!touchedSet.size) return;

 var shInscName = _pickSheetName_(ss, SHEETS.INSCRIPTIONS_FINAL, SHEETS.INSCRIPTIONS);
var shArtName  = _pickSheetName_(ss, SHEETS.ARTICLES_FINAL,     SHEETS.ARTICLES);

var insc = readSheetAsObjects_(ss.getId(), shInscName);
var art  = readSheetAsObjects_(ss.getId(), shArtName);


  // 1) Lire ledger existant et retirer les lignes de ces passeports pour la saison
  var ledger = readSheetAsObjects_(ss.getId(), 'ACHATS_LEDGER');
  var existing = ledger.rows || [];
  var kept = existing.filter(function(r){
    var p = String(r['Passeport #']||'').trim();
    return !(touchedSet.has(p) && r['Saison'] === saison);
  });
  writeObjectsToSheet_(ss, 'ACHATS_LEDGER', kept, ledger.header || [
    'Passeport #','Type','NomFrais','Status','isIgnored','RowHash','Saison','CreatedAt','UpdatedAt'
  ]);

  // 2) Re-créer les lignes pour ces passeports
  var toAppend = [];
  function consider_(type, r){
    var p = String(r['Passeport #']||'').trim();
    if (!p || !touchedSet.has(p)) return;
    var name = r['Nom du frais'] || r['Frais'] || r['Produit'] || '';
    var status = _isActiveRow_(r) ? 1 : 0;
    var isIgnored = _feeIgnoredLocal_(name, ignoreSet) ? 1 : 0;
    toAppend.push({
      'Passeport #': p,
      'Type': type,
      'NomFrais': name,
      'Status': status,
      'isIgnored': isIgnored,
      'RowHash': r['ROW_HASH'] || '',
      'Saison': saison,
      'CreatedAt': new Date(),
      'UpdatedAt': new Date()
    });
  }
  (insc.rows||[]).forEach(function(r){ consider_('INSCRIPTION', r); });
  (art.rows ||[]).forEach(function(r){ consider_('ARTICLE',     r); });

  if (toAppend.length) appendObjectsToSheet_(ss, 'ACHATS_LEDGER', toAppend);
}

/** =========================
 *  JOUEURS — FULL
 *  ========================= */
function buildJoueursIndex_(ss) {
  var saison    = readParam_(ss, 'SEASON_LABEL') || '';
  var campCsv   = readParam_(ss, PARAM_KEYS.RETRO_CAMP_KEYWORDS)   || 'camp de selection u13,camp selection u13,camp u13';
  var adapteCsv = readParam_(ss, PARAM_KEYS.RETRO_ADAPTE_KEYWORDS) || 'adapté,adapte,adapte';
  var ignoreCsv = readParam_(ss, PARAM_KEYS.RETRO_IGNORE_FEES_CSV) || 'senior,u-se,adulte,ligue';

  var rxCamp     = _compileKeywordsToRegex_(campCsv);
  var rxAdapte   = _compileKeywordsToRegex_(adapteCsv);
  var ignoreSet  = _compileCsvToSet_(ignoreCsv);

  var ledger = readSheetAsObjects_(ss.getId(), 'ACHATS_LEDGER');
  var mem    = readSheetAsObjects_(ss.getId(), SHEETS.MEMBRES_GLOBAL || 'MEMBRES_GLOBAL');

  // Emails: priorité INSCRIPTIONS_FINAL, fallback ARTICLES_FINAL
var shInscName = _pickSheetName_(ss, SHEETS.INSCRIPTIONS_FINAL, SHEETS.INSCRIPTIONS);
var shArtName  = _pickSheetName_(ss, SHEETS.ARTICLES_FINAL,     SHEETS.ARTICLES);

var inscF = readSheetAsObjects_(ss.getId(), shInscName);
var artF  = readSheetAsObjects_(ss.getId(), shArtName);

  var memByPass = _indexBy_(mem.rows||[], function(r){
    return String(r['Passeport #'] || r['Passeport'] || '').trim();
  });

  var emailsByPass = {};
  (inscF.rows||[]).forEach(function(r){
    var p = String(r['Passeport #']||'').trim(); if (!p) return;
    var e = collectEmailsFromRow_(r, 'Courriel,Parent 1 - Courriel,Parent 2 - Courriel');
    if (e) _addEmails_(emailsByPass, p, e);
  });
  (artF.rows||[]).forEach(function(r){
    var p = String(r['Passeport #']||'').trim(); if (!p) return;
    if (!emailsByPass[p] && r['Courriel']) _addEmails_(emailsByPass, p, r['Courriel']);
  });

  // Agrégation par passeport depuis le ledger
  var byPass = {};
  (ledger.rows||[]).forEach(function(r){
    if (r['Saison'] !== saison) return;
    var p = String(r['Passeport #']||'').trim(); if (!p) return;
    if (!byPass[p]) byPass[p] = { insc:[], art:[], hasInscription:false, hasCamp:false, isAdapte:0, cdpCount:null };

    var name = r['NomFrais'] || '';
    var s    = Number(r['Status'])||0;
    var ign  = Number(r['isIgnored'])||0;

    // Listes complètes pour l'UI (inclure annulés)
    if (r['Type'] === 'INSCRIPTION') byPass[p].insc.push({name:name, s:s});
    else                             byPass[p].art.push({name:name, s:s});

    // Flags opérationnels (ignorer les frais "ignorés")
    if (!ign) {
      if (r['Type'] === 'INSCRIPTION') {
        if (s===1) {
          byPass[p].hasInscription = true;
          if (rxAdapte && rxAdapte.test(name)) byPass[p].isAdapte = 1;
        }
      } else { // ARTICLE
        if (s===1 && rxCamp && rxCamp.test(name)) byPass[p].hasCamp = true;
      }
      // cdpCount (détection simple sur n'importe quel achat actif)
      if (s===1 && _isCdpName_(name)) {
        var n = _cdpCountFromName_(name);
        byPass[p].cdpCount = Math.max(byPass[p].cdpCount||0, n);
      }
    }
  });

  var currentYear = parseSeasonYear_(saison) || (new Date()).getFullYear();
  var rows = [];

  Object.keys(byPass).forEach(function(p){
    var j = byPass[p];
    var id = memByPass[p] || {};
    var nom   = id['Nom'] || '';
    var pren  = id['Prénom'] || id['Prenom'] || '';
    var dna   = id['Date de naissance'] || id['Naissance'] || '';
    var genre = (id['Identité de genre']||'').toString().trim().toUpperCase().charAt(0);
    var emails = (emailsByPass[p]||[]).join('; ');

    // U9–U12 → cdpCount=0 si non-adapté et indéfini
    var by = _extractBirthYearLoose_(dna);
    var age = by ? (currentYear - by) : 0;
    if (age >= 9 && age <= 12 && j.isAdapte !== 1) {
      if (j.cdpCount == null) j.cdpCount = 0;
    }

    // Photo (brute + formatée)
    var tmp = {}; tmp['PhotoExpireLe'] = id['PhotoExpireLe'] || '';
    var photoStr = _computePhotoCell_(ss, tmp);

    rows.push({
      'Passeport #': p,
      'Nom': nom,
      'Prénom': pren,
      'DateNaissance': dna,
      'Genre': genre,
      'Courriels': emails,
      'isAdapte': j.isAdapte,
      'cdpCount': j.cdpCount,
      'hasCamp': j.hasCamp ? 'Oui' : 'Non',
      'hasInscription': j.hasInscription ? 'Oui' : 'Non',
      'PhotoExpireLe': id['PhotoExpireLe'] || '',
      'PhotoStr': photoStr,
      'InscriptionsJSON': JSON.stringify(j.insc),
      'ArticlesJSON': JSON.stringify(j.art)
    });
  });

  writeObjectsToSheet_(ss, 'JOUEURS', rows, [
    'Passeport #','Nom','Prénom','DateNaissance','Genre','Courriels',
    'isAdapte','cdpCount','hasCamp','hasInscription',
    'PhotoExpireLe','PhotoStr','InscriptionsJSON','ArticlesJSON'
  ]);
}

/** =========================================
 *  JOUEURS — INCR (par passeports)
 *  ========================================= */
function updateJoueursForPassports_(ss, touchedPassports) {
  var saison    = readParam_(ss, 'SEASON_LABEL') || '';
  var campCsv   = readParam_(ss, PARAM_KEYS.RETRO_CAMP_KEYWORDS)   || 'camp de selection u13,camp selection u13,camp u13';
  var adapteCsv = readParam_(ss, PARAM_KEYS.RETRO_ADAPTE_KEYWORDS) || 'adapté,adapte,adapte';
  var ignoreCsv = readParam_(ss, PARAM_KEYS.RETRO_IGNORE_FEES_CSV) || 'senior,u-se,adulte,ligue';

  var rxCamp     = _compileKeywordsToRegex_(campCsv);
  var rxAdapte   = _compileKeywordsToRegex_(adapteCsv);
  var ignoreSet  = _compileCsvToSet_(ignoreCsv);
  var touchedSet = _toPassportSet_(touchedPassports);
  if (!touchedSet.size) return;

  var ledger = readSheetAsObjects_(ss.getId(), 'ACHATS_LEDGER');
  var mem    = readSheetAsObjects_(ss.getId(), SHEETS.MEMBRES_GLOBAL || 'MEMBRES_GLOBAL');

var shInscName = _pickSheetName_(ss, SHEETS.INSCRIPTIONS_FINAL, SHEETS.INSCRIPTIONS);
var shArtName  = _pickSheetName_(ss, SHEETS.ARTICLES_FINAL,     SHEETS.ARTICLES);

var inscF = readSheetAsObjects_(ss.getId(), shInscName);
var artF  = readSheetAsObjects_(ss.getId(), shArtName);

  var memByPass = _indexBy_(mem.rows||[], function(r){
    return String(r['Passeport #'] || r['Passeport'] || '').trim();
  });

  var emailsByPass = {};
  (inscF.rows||[]).forEach(function(r){
    var p = String(r['Passeport #']||'').trim(); if (!p) return;
    var e = collectEmailsFromRow_(r, 'Courriel,Parent 1 - Courriel,Parent 2 - Courriel');
    if (e) _addEmails_(emailsByPass, p, e);
  });
  (artF.rows||[]).forEach(function(r){
    var p = String(r['Passeport #']||'').trim(); if (!p) return;
    if (!emailsByPass[p] && r['Courriel']) _addEmails_(emailsByPass, p, r['Courriel']);
  });

  // Construire uniquement pour les passeports touchés
  var byPass = {};
  (ledger.rows||[]).forEach(function(r){
    if (r['Saison'] !== saison) return;
    var p = String(r['Passeport #']||'').trim();
    if (!p || !touchedSet.has(p)) return;

    if (!byPass[p]) byPass[p] = { insc:[], art:[], hasInscription:false, hasCamp:false, isAdapte:0, cdpCount:null };

    var name = r['NomFrais'] || '';
    var s    = Number(r['Status'])||0;
    var ign  = Number(r['isIgnored'])||0;

    if (r['Type'] === 'INSCRIPTION') byPass[p].insc.push({name:name, s:s});
    else                             byPass[p].art.push({name:name, s:s});

    if (!ign) {
      if (r['Type'] === 'INSCRIPTION') {
        if (s===1) {
          byPass[p].hasInscription = true;
          if (rxAdapte && rxAdapte.test(name)) byPass[p].isAdapte = 1;
        }
      } else {
        if (s===1 && rxCamp && rxCamp.test(name)) byPass[p].hasCamp = true;
      }
      if (s===1 && _isCdpName_(name)) {
        var n = _cdpCountFromName_(name);
        byPass[p].cdpCount = Math.max(byPass[p].cdpCount||0, n);
      }
    }
  });

  var currentYear = parseSeasonYear_(saison) || (new Date()).getFullYear();
  var newRows = [];

  Object.keys(byPass).forEach(function(p){
    var j = byPass[p];
    var id = memByPass[p] || {};
    var nom   = id['Nom'] || '';
    var pren  = id['Prénom'] || id['Prenom'] || '';
    var dna   = id['Date de naissance'] || id['Naissance'] || '';
    var genre = (id['Identité de genre']||'').toString().trim().toUpperCase().charAt(0);
    var emails = (emailsByPass[p]||[]).join('; ');

    var by = _extractBirthYearLoose_(dna);
    var age = by ? (currentYear - by) : 0;
    if (age >= 9 && age <= 12 && j.isAdapte !== 1) {
      if (j.cdpCount == null) j.cdpCount = 0;
    }

    var tmp = {}; tmp['PhotoExpireLe'] = id['PhotoExpireLe'] || '';
    var photoStr = _computePhotoCell_(ss, tmp);

    newRows.push({
      'Passeport #': p,
      'Nom': nom,
      'Prénom': pren,
      'DateNaissance': dna,
      'Genre': genre,
      'Courriels': emails,
      'isAdapte': j.isAdapte,
      'cdpCount': j.cdpCount,
      'hasCamp': j.hasCamp ? 'Oui' : 'Non',
      'hasInscription': j.hasInscription ? 'Oui' : 'Non',
      'PhotoExpireLe': id['PhotoExpireLe'] || '',
      'PhotoStr': photoStr,
      'InscriptionsJSON': JSON.stringify(j.insc),
      'ArticlesJSON': JSON.stringify(j.art)
    });
  });

  // Upsert léger : enlever les lignes existantes pour ces passeports, puis append
  var joueurs = readSheetAsObjects_(ss.getId(), 'JOUEURS');
  var existing = joueurs.rows || [];
  var kept = existing.filter(function(r){
    var p = String(r['Passeport #']||'').trim();
    return !touchedSet.has(p);
  });
  writeObjectsToSheet_(ss, 'JOUEURS', kept, joueurs.header || [
    'Passeport #','Nom','Prénom','DateNaissance','Genre','Courriels',
    'isAdapte','cdpCount','hasCamp','hasInscription',
    'PhotoExpireLe','PhotoStr','InscriptionsJSON','ArticlesJSON'
  ]);
  if (newRows.length) appendObjectsToSheet_(ss, 'JOUEURS', newRows);
}

/* ==================
 * Helpers locaux
 * ================== */
function _compileCsvToSet_(csv){
  return new Set(String(csv||'').split(',').map(function(s){return s.trim().toLowerCase();}).filter(Boolean));
}
function _compileKeywordsToRegex_(csv){
  var arr = String(csv||'').split(',').map(function(s){return s.trim();}).filter(Boolean);
  if (!arr.length) return null;
  var esc = arr.map(function(s){return s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');});
  return new RegExp('(?:^|\\b)('+esc.join('|')+')(?:\\b|$)','i');
}
function _feeIgnoredLocal_(name, ignoreSet){
  var key = _feeKey_(name);
  return ignoreSet.has(key);
}
function _feeKey_(name){
  return String(name||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'')
               .toLowerCase().replace(/\s+/g,' ').trim();
}
function _toPassportSet_(arrOrSet){
  if (!arrOrSet) return new Set();
  if (arrOrSet instanceof Set) return arrOrSet;
  if (Array.isArray(arrOrSet)) return new Set(arrOrSet.map(function(x){return String(x).trim();}));
  // objet map {p:1} ?
  var out = new Set();
  Object.keys(arrOrSet).forEach(function(k){ if (arrOrSet[k]) out.add(String(k).trim()); });
  return out;
}
function _indexBy_(rows, keyFn){
  var o = {}; (rows||[]).forEach(function(r){ var k = keyFn(r); if (k) o[k]=r; }); return o;
}
function _addEmails_(map, p, csv){
  var arr = String(csv||'').split(',').map(function(s){return s.trim();}).filter(Boolean);
  if (!map[p]) map[p] = [];
  arr.forEach(function(e){ if (map[p].indexOf(e)===-1) map[p].push(e); });
}
function _isCdpName_(name){
  var s = _feeKey_(name);
  return s.indexOf('cdp') !== -1;
}
function _cdpCountFromName_(name){
  var s = _feeKey_(name);
  if (/\b2\b/.test(s) || /2\s*entrainement/.test(s) || /2\s*entrainements/.test(s)) return 2;
  if (/\b1\b/.test(s) || /1\s*entrainement/.test(s) || /1\s*entrainements/.test(s)) return 1;
  return 1; // CDP sans chiffre explicite => au moins 1
}
/*************************************************
 *  RÈGLES — versions rapides (FULL & INCR)
 *  - S’appuie sur ACHATS_LEDGER + JOUEURS
 *  - Ecrit ERREURS en batch
 *************************************************/

// === PUBLIC: remplace ta version FULL
function runEvaluateRulesFast_Impl() {
  var seasonId = getSeasonId_();
  var ss = getSeasonSpreadsheet_(seasonId);
  var t0 = new Date().getTime();

  // 1) Clear (FULL)
  _rulesClearErreursSheet_(ss); // log interne

  // 2) Build erreurs depuis Ledger+Joueurs
  var res = _rulesBuildErrorsFast_(ss, /*touchedSet*/null);

  // 3) Write full
  _rulesWriteFull_(ss, res.errors, res.header);

  var t1 = new Date().getTime();
  appendImportLog_(ss, 'RULES_DONE', JSON.stringify({
    dryRun:false, append:false, filtered:false,
    ledRows: res.ledgerCount, joueursRows: res.joueursCount,
    written: res.errors.length, elapsedMs:(t1-t0)
  }));
  return { written: res.errors.length, elapsedMs:(t1-t0) };
}

// === PUBLIC: remplace ta version INCR
function evaluateSeasonRulesIncrFast_Impl(touchedPassports, ss) {
  ss = ss || getSeasonSpreadsheet_(getSeasonId_());
  var t0 = new Date().getTime();

  var touchedSet = _toPassportSet_(touchedPassports);
  if (!touchedSet.size) {
    appendImportLog_(ss, 'RULES_INCR_SKIP', JSON.stringify({reason:'no-passports'}));
    return { written:0, skipped:true };
  }

  // 1) (ré)calculer erreurs pour ces passeports seulement
  var res = _rulesBuildErrorsFast_(ss, touchedSet);

  // 2) Upsert: lire ERREURS, enlever lignes de ces passeports, puis réécrire + append
  _rulesUpsertForPassports_(ss, res.errors, touchedSet, res.header);

  var t1 = new Date().getTime();
  appendImportLog_(ss, 'RULES_INCR_DONE', JSON.stringify({
    touched: touchedSet.size, written: res.errors.length,
    ledRows: res.ledgerCount, joueursRows: res.joueursCount,
    elapsedMs:(t1-t0)
  }));
  return { written: res.errors.length, elapsedMs:(t1-t0) };
}

/* =========================
 * Implémentation interne
 * ========================= */
function _rulesBuildErrorsFast_(ss, touchedSet){
  var saison = readParam_(ss, 'SEASON_LABEL') || '';

  // Charger Ledger & Joueurs (1 lecture chacun)
  var ledger = readSheetAsObjects_(ss.getId(), SHEETS.ACHATS_LEDGER);
  var joueurs = readSheetAsObjects_(ss.getId(), SHEETS.JOUEURS);

  var rules = _getCompiledRulesOrFallback_(ss); // ignoreFees, rxCamp, exclusifs, etc.

  // Index Joueurs (identité + flags)
  var jByPass = {};
  (joueurs.rows||[]).forEach(function(r){
    var p = String(r['Passeport #']||'').trim(); if (!p) return;
    if (touchedSet && !touchedSet.has(p)) return;
    jByPass[p] = r;
  });

  // Grouper les achats ACTIFS & NON ignorés, par passeport & type
  var activeByPass = {}; // p -> { ART:{ feeKey -> {name,count}}, INSC:{...}, anyCamp:boolean }
  (ledger.rows||[]).forEach(function(r){
    if (r['Saison'] !== saison) return;
    var p = String(r['Passeport #']||'').trim(); if (!p) return;
    if (touchedSet && !touchedSet.has(p)) return;

    var status = Number(r['Status'])||0;
    var ign = Number(r['isIgnored'])||0;
    var type = r['Type'] === 'INSCRIPTION' ? 'INSC' : 'ART';
    var name = r['NomFrais'] || '';
    var k = _feeKey_(name);

    if (!activeByPass[p]) activeByPass[p] = { ART:{}, INSC:{}, ANY_CAMP:false };

    if (status===1 && !ign) {
      var bucket = activeByPass[p][type];
      bucket[k] = bucket[k] || { name:name, count:0 };
      bucket[k].count++;

      if (rules.rxCamp && rules.rxCamp.test(name)) activeByPass[p].ANY_CAMP = true;
    }
  });

  // Construire erreurs
  var errors = [];
  var todayStr = Utilities.formatDate(new Date(), Session.getScriptTimeZone(), 'yyyy-MM-dd');

  Object.keys(activeByPass).forEach(function(p){
    var packs = activeByPass[p];
    var j = jByPass[p] || {}; // identité & flags
    var nom = j['Nom'] || '';
    var prenom = j['Prénom'] || j['Prenom'] || '';
    var display = (prenom + ' ' + nom).trim();
    var saisonLbl = saison;

    // 1) DUPLICAT (ARTICLES): même NomFrais actif >1
    Object.keys(packs.ART).forEach(function(k){
      var rec = packs.ART[k];
      if (rec.count > 1) {
        errors.push(_errRow_({
          passeport:p, nom:nom, prenom:prenom, display:display,
          category:'ARTICLES', code:'DUPLICAT', level:'warn',
          element: rec.name, message:'Article en double détecté',
          meta: { count:rec.count }, saison:saisonLbl, date:todayStr
        }));
      }
    });

    // 2) EXCLUSIVITE: >1 article actif dans le même groupe exclusif
    var countsByGroup = {};
    Object.keys(packs.ART).forEach(function(k){
      var rec = packs.ART[k];
      var grp = rules.exclusiveGroupByItem.get(k);
      if (!grp) return;
      countsByGroup[grp] = (countsByGroup[grp]||0) + 1;
    });
    Object.keys(countsByGroup).forEach(function(grp){
      if (countsByGroup[grp] > 1) {
        errors.push(_errRow_({
          passeport:p, nom:nom, prenom:prenom, display:display,
          category:'ARTICLES', code:'EXCLUSIVITE', level:'error',
          element: grp, message:'Conflit d’articles exclusifs (groupe: '+grp+')',
          meta: { group:grp, count:countsByGroup[grp] }, saison:saisonLbl, date:todayStr
        }));
      }
    });

    // 3) U13U18_CAMP_SEUL: a un camp actif mais pas d’inscription active
    var hasInscription = Object.keys(packs.INSC).length > 0;
    var hasCamp = packs.ANY_CAMP === true;
    if (hasCamp && !hasInscription) {
      // (option) si tu veux restreindre à U13–U18, décommente:
      var dna = j['DateNaissance'] || j['Naissance'] || '';
      var curY = parseSeasonYear_(saisonLbl) || (new Date()).getFullYear();
      var by = _extractBirthYearLoose_(dna);
      var age = by ? (curY - by) : 0;
      if (!age || (age >= 13 && age <= 18)) {
        errors.push(_errRow_({
          passeport:p, nom:nom, prenom:prenom, display:display,
          category:'ARTICLES', code:'U13U18_CAMP_SEUL', level:'warn',
          element: 'Camp', message:'Inscrit à un camp de sélection mais pas à la saison',
          meta: {}, saison:saisonLbl, date:todayStr
        }));
      }
    }
  });

  return {
    header: _erreursHeader_(ss),
    errors: errors,
    ledgerCount: (ledger.rows||[]).length,
    joueursCount: (joueurs.rows||[]).length
  };
}

/* =========================
 *  E/S ERREURS — batch
 * ========================= */
function _rulesClearErreursSheet_(ss){
  var sh = ss.getSheetByName('ERREURS') || ss.insertSheet('ERREURS');
  sh.clear(); // garde formatage; on réécrit un header cohérent
  appendImportLog_(ss, 'RULES_CLEAR_FULL', 'ERREURS reset (append=FALSE, no filter)');
}

function _rulesWriteFull_(ss, errs, header){
  writeObjectsToSheet_(ss, 'ERREURS', errs, header);
}

function _rulesUpsertForPassports_(ss, newErrs, touchedSet, header){
  var cur = readSheetAsObjects_(ss.getId(), 'ERREURS');
  var kept = (cur.rows||[]).filter(function(r){
    var p = String(r['Passeport #']||r['Passeport']||'').trim();
    return !touchedSet.has(p);
  });
  // rewrite + append
  writeObjectsToSheet_(ss, 'ERREURS', kept, cur.header || header);
  if (newErrs.length) appendObjectsToSheet_(ss, 'ERREURS', newErrs);
}

/* =========================
 *  Helpers erreurs & règles
 * ========================= */
function _erreursHeader_(ss){
  // Essaie de réutiliser l’en-tête existant si présent
  var cur = readSheetAsObjects_(ss.getId(), 'ERREURS');
  if (cur && cur.header && cur.header.length) return cur.header;
  // Sinon header par défaut (adapter si besoin à ta feuille)
  return [
    'Passeport #','Nom','Prénom','Affichage','Catégorie','Code','Niveau',
    'Saison','Élément','Message','Meta','Date'
  ];
}

function _errRow_(o){
  return {
    'Passeport #': o.passeport || '',
    'Nom': o.nom || '',
    'Prénom': o.prenom || '',
    'Affichage': o.display || '',
    'Catégorie': o.category || '',
    'Code': o.code || '',
    'Niveau': o.level || 'warn',
    'Saison': o.saison || '',
    'Élément': o.element || '',
    'Message': o.message || '',
    'Meta': JSON.stringify(o.meta || {}),
    'Date': o.date || ''
  };
}

// Tente de charger un ruleset précompilé si présent; sinon minimalistes
function _getCompiledRulesOrFallback_(ss){
  var out = {
    ignoreFees: new Set(),
    rxCamp: _compileKeywordsToRegex_(readParam_(ss, PARAM_KEYS.RETRO_CAMP_KEYWORDS) || 'camp de selection u13,camp selection u13,camp u13'),
    exclusiveGroupByItem: new Map()
  };
  try {
    if (typeof loadRetroRulesFast_ === 'function') {
      var r = loadRetroRulesFast_(ss);
      if (r.ignoreFees) out.ignoreFees = r.ignoreFees;
      if (r.rxCamp) out.rxCamp = r.rxCamp;
      if (r.exclusiveGroupByItem) out.exclusiveGroupByItem = r.exclusiveGroupByItem;
      return out;
    }
  } catch(e){}
  // Fallback exclusifs depuis MAPPING si tu as une fonction
  try {
    if (typeof loadExclusiveGroupsMapping_ === 'function') {
      var mapping = loadExclusiveGroupsMapping_(ss); // [{group:'CDP_ENTRAINEMENT', items:[...]}]
      mapping.forEach(function(g){
        (g.items||[]).forEach(function(name){
          out.exclusiveGroupByItem.set(_feeKey_(name), g.group);
        });
      });
    }
  } catch(e){}
  return out;
}
