/***** server_rules.js — révisé *****/

/* ---------------------------------
   Helpers "ignore frais (RÉTRO)"
---------------------------------- */

// normalise (trim, minuscule, sans accents)
function SR_norm_(s) {
  return String(s || '')
    .trim()
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '');
}

// Vrai si le "Nom du frais" doit être ignoré selon RETRO_IGNORE_FEES_CSV (+ RETRO_COACH_FEES_CSV)
function SR_isIgnoredFeeRetro_(ss, fee) {
  var v = SR_norm_(fee);
  if (!v) return false;

  var baseCsv  = readParam_(ss, PARAM_KEYS.RETRO_IGNORE_FEES_CSV) || '';
  var coachCsv = readParam_(ss, 'RETRO_COACH_FEES_CSV') || '';
  var toks = (baseCsv + (baseCsv && coachCsv ? ',' : '') + coachCsv)
    .split(',')
    .map(SR_norm_)
    .filter(Boolean);

  if (toks.indexOf(v) >= 0) return true; // exact
  for (var i = 0; i < toks.length; i++)  // contains
    if (v.indexOf(toks[i]) >= 0) return true;

  // filet lexical si paramétrage incomplet
  if (/(entraineur|entra[îi]neur|coach)/i.test(String(fee || ''))) return true;

  return false;
}

/* ---------------------------------
   Get/Set des règles (UI)
---------------------------------- */

function getRules(seasonId) {
  return _wrap('getRules', function () {
    var ss = getSeasonSpreadsheet_(seasonId);
    var sh = ss.getSheetByName('RETRO_RULES_JSON');
    var text = sh && sh.getLastRow() > 0 ? String(sh.getRange(1, 1).getValue() || '') : '';
    if (!text) {
      var p = ss.getSheetByName('PARAMS');
      if (p) {
        var values = p.getDataRange().getValues();
        for (var i = 1; i < values.length; i++) {
          if (values[i][0] === 'RETRO_RULES_JSON') { text = String(values[i][1] || ''); break; }
        }
      }
    }
    var parsed = null, ok = true, err = '';
    if (text && String(text).trim()) {
      try { parsed = JSON.parse(text); } catch (e) { ok = false; err = String(e); }
    }
    return _ok({ jsonText: text, parsed: parsed, parsedOk: ok, error: err });
  });
}

function setRules(seasonId, jsonText) {
  return _wrap('setRules', function () {
    try { if (jsonText && jsonText.trim()) JSON.parse(jsonText); }
    catch (e) { throw new Error('Invalid JSON: ' + e); }
    var ss = getSeasonSpreadsheet_(seasonId);
    var sh = ss.getSheetByName('RETRO_RULES_JSON') || ss.insertSheet('RETRO_RULES_JSON');
    sh.clear();
    sh.getRange(1, 1).setValue(jsonText);
    return _ok(null, 'Rules saved');
  });
}

/* ---------------------------------
   Utils: obtenir un Spreadsheet
---------------------------------- */

// Force/convertit n’importe quoi en Spreadsheet (object déjà-ouvert, ID string, rien → saison courante)
function _asSpreadsheet_(ssOrId) {
  if (ssOrId && typeof ssOrId.getSheetByName === 'function') return ssOrId; // déjà un Spreadsheet
  if (typeof ssOrId === 'string' && ssOrId) return SpreadsheetApp.openById(ssOrId);
  if (typeof getSeasonSpreadsheet_ === 'function' && typeof getSeasonId_ === 'function') {
    return getSeasonSpreadsheet_(getSeasonId_());
  }
  // Fallback ultime si les helpers ne sont pas là
  if (typeof getSeasonId_ === 'function') return SpreadsheetApp.openById(getSeasonId_());
  throw new Error('_asSpreadsheet_: impossible d’obtenir un Spreadsheet valide');
}

/* ---------------------------------
   Cache 5 min pour règles
---------------------------------- */

// Cache 5 min (garde ton cache global si déjà présent)
var __retroRulesCacheObj = (typeof __retroRulesCacheObj !== 'undefined') ? __retroRulesCacheObj : { at: 0, obj: null };

// Lis le JSON brut (PARAM d’abord, puis feuille RETRO_RULES_JSON), sinon ''.
function _SR_readRulesRaw_(ss) {
  var raw = readParam_(ss, PARAM_KEYS.RETRO_RULES_JSON) || '';
  if (!raw) {
    var shJson = ss.getSheetByName('RETRO_RULES_JSON');
    if (shJson && shJson.getLastRow() >= 1 && shJson.getLastColumn() >= 1) {
      var vals = shJson.getDataRange().getDisplayValues();
      var pieces = [];
      for (var i = 0; i < vals.length; i++) {
        for (var j = 0; j < vals[i].length; j++) {
          var cell = vals[i][j];
          if (cell != null && String(cell).trim() !== '') pieces.push(String(cell));
        }
      }
      raw = pieces.join('\n');
      try { appendImportLog_(ss, 'RETRO_RULES_JSON_SHEET_READ', 'chars=' + raw.length); } catch (_) {}
    }
  }
  return raw;
}

// Renvoie un OBJET {inscriptions:[], articles:[], member:[]} (fallback inclus)
function SR_loadRetroRulesObj_(ss) {
  var now = Date.now();
  if (__retroRulesCacheObj.obj && (now - __retroRulesCacheObj.at) < 5 * 60 * 1000) return __retroRulesCacheObj.obj;

  var raw = _SR_readRulesRaw_(ss);
  var obj = null;

  if (raw) {
    try {
      var parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) {
        // legacy → objet
        obj = { inscriptions: [], articles: [], member: [] };
        parsed.forEach(function (r) {
          var scope = (r && r.scope) || 'inscriptions';
          var copy = Object.assign({}, r); delete copy.scope;
          (obj[scope] = obj[scope] || []).push(copy);
        });
      } else if (parsed && typeof parsed === 'object') {
        obj = { inscriptions: [], articles: [], member: [] };
        ['inscriptions', 'articles', 'member'].forEach(function (k) {
          if (Array.isArray(parsed[k])) obj[k] = parsed[k];
        });
      }
    } catch (e) {
      try { appendImportLog_(ss, 'RETRO_RULES_JSON_PARSE_FAIL', String(e)); } catch (_) {}
    }
  }

  // Fallback “comportement actuel” si manquant
  if (!obj) {
    // Lis tes CSV/params existants pour ignorer coachs/adapté etc.
    var ignoreCsv = readParam_(ss, PARAM_KEYS.RETRO_IGNORE_FEES_CSV) || '';
    var coachCsv  = readParam_(ss, 'RETRO_COACH_FEES_CSV') || '';
    var adapteCsv = readParam_(ss, PARAM_KEYS.RETRO_ADAPTE_KEYWORDS) || '';

    obj = {
      inscriptions: [
        // Exclure frais ignorés & entraîneurs (CSV + filet lexical côté lib)
        { action: 'ignore_row', when: [{ col: 'Nom du frais', op: 'contains', val: ignoreCsv }] },
        { action: 'ignore_row', when: [{ col: 'Nom du frais', op: 'contains', val: coachCsv  }] },
        // Flag “adapté” si mot-clé trouvé
        { action: 'set_member_field', field: 'adapte', value: '1',
          when: [{ col: 'Nom du frais', op: 'contains', val: adapteCsv }] }
      ],
      articles: [],
      member: []
    };
    try { appendImportLog_(ss, 'RETRO_RULES_JSON_FALLBACK', 'using PARAMS-derived defaults'); } catch (_) {}
  }

  __retroRulesCacheObj = { at: now, obj: obj };
  return obj;
}

// Back-compat : si du code attend encore "une liste aplatie"
function SR_loadRetroRules_(ss) {
  var o = SR_loadRetroRulesObj_(ss);
  var flat = [];
  ['inscriptions', 'articles', 'member'].forEach(function (scope) {
    (o[scope] || []).forEach(function (r) {
      var copy = Object.assign({ scope: scope }, r);
      flat.push(copy);
    });
  });
  return flat;
}

/************* RÈGLES — INCR *************/
/**
 * Évalue les règles uniquement pour les passeports fournis (traitement ciblé).
 * @param {string[]} passports
 * @param {Spreadsheet|string|GoogleAppsScript.Drive.File=} ssOrId
 */
function evaluateSeasonRulesIncr(passports, ssOrId) {
  // 0) sécuriser un Spreadsheet valide
  var ss = _asSpreadsheet_(ssOrId);

  // 1) normaliser la liste
  passports = (passports || []).map(normalizePassportPlain8_).filter(Boolean);
  if (!passports.length) {
    return { ok: true, scanned: 0, written: 0, deleted: 0, note: 'no-passports' };
  }

  // 2) cache per-run
  if (typeof _rulesPerfCacheBegin_ === 'function') _rulesPerfCacheBegin_(ss);

  try {
    // 3) charger règles (UI JSON → objet) ou fallback
    var rules = (typeof SR_loadRetroRulesObj_ === 'function')
      ? SR_loadRetroRulesObj_(ss)
      : (typeof SR_loadRetroRules_ === 'function' ? SR_loadRetroRules_(ss) : []);

    var set = new Set(passports);

    // 4) lire STAGING filtrés
    var ins = (typeof _readStagingInscriptionsByPassports_ === 'function')
      ? _readStagingInscriptionsByPassports_(ss, set)
      : { header: [], rows: [], rowsCount: 0 };
    var art = (typeof _readStagingArticlesByPassports_ === 'function')
      ? _readStagingArticlesByPassports_(ss, set)
      : { header: [], rows: [], rowsCount: 0 };

    // 5) moteur
    var res = (typeof _evaluateRulesCore_ === 'function')
      ? _evaluateRulesCore_({ ss: ss, rules: rules, ins: ins, art: art, targetPassports: set })
      : { errors: [] };

    // 6) MAJ ERREURS ciblée
    var deleted = (typeof _deleteErrorsForPassports_ === 'function')
      ? _deleteErrorsForPassports_(ss, passports)
      : 0;
    var written = (typeof _appendErrors_ === 'function')
      ? _appendErrors_(ss, res.errors || [])
      : 0;

    var scanned = (ins.rowsCount || (ins.rows && ins.rows.length) || 0)
                + (art.rowsCount || (art.rows && art.rows.length) || 0);

    return { ok: true, scanned: scanned, written: written | 0, deleted: deleted | 0 };
  } catch (e) {
    try { appendImportLog_(ss, 'RULES_INCR_FAIL', String(e)); } catch (_) {}
    return { ok: false, error: String(e) };
  } finally {
    if (typeof _rulesPerfCacheEnd_ === 'function') _rulesPerfCacheEnd_();
  }
}

/**
 * Rejoue l'incrémental à partir de LAST_TOUCHED_PASSPORTS (props)
 * Garde compat: si aucun spreadsheet n'est passé, la fonction ouvrira la saison via helpers.
 */
function runEvaluateRulesIncrFromLastTouched(ssOrId) {
  var raw = PropertiesService.getDocumentProperties().getProperty('LAST_TOUCHED_PASSPORTS') || '[]';
  var list = (raw[0] === '[' ? JSON.parse(raw) : raw.split(',')).map(String).filter(Boolean);
  return evaluateSeasonRulesIncr(list, ssOrId); // on passe ssOrId si fourni (sinon fallback interne)
}

/* ---------------------------------
   Helpers ciblés + lecture STAGING
---------------------------------- */

/**
 * Supprime les lignes d'ERREURS pour une liste de passeports.
 * Accepte Spreadsheet | id | DriveFile.
 */
function _deleteErrorsForPassports_(ssOrId, passports) {
  var ss = _asSpreadsheet_(ssOrId);

  var sh = ss.getSheetByName('ERREURS');
  if (!sh || sh.getLastRow() < 2) return 0;

  // header + index
  var H = sh.getRange(1, 1, 1, sh.getLastColumn()).getValues()[0] || [];
  // tolère "Passeport #" et "Passeport"
  var cP = H.indexOf('Passeport #');
  if (cP < 0) cP = H.indexOf('Passeport');
  if (cP < 0) return 0;

  var set = new Set((passports || []).map(normalizePassportPlain8_).filter(Boolean));

  var last = sh.getLastRow();
  var V = sh.getRange(2, 1, last - 1, sh.getLastColumn()).getValues();

  var toDel = [];
  for (var i = 0; i < V.length; i++) {
    var p = normalizePassportPlain8_(V[i][cP]);
    if (p && set.has(p)) toDel.push(2 + i); // +1 header, +1 base=1
  }
  if (!toDel.length) return 0;

  // delete bottom-up
  toDel.sort(function (a, b) { return b - a; });
  for (var k = 0; k < toDel.length; k++) { sh.deleteRow(toDel[k]); }
  return toDel.length;
}

// lecture partielle STAGING_* (filtre par passeport)
function _readStagingInscriptionsByPassports_(ss, passSet) {
  var sh = ss.getSheetByName('STAGING_INSCRIPTIONS');
  if (!sh || sh.getLastRow() < 2) return { header: [], rows: [], rowsCount: 0 };
  var V = sh.getDataRange().getValues(), H = V[0], cP = H.indexOf('Passeport');
  if (cP < 0) return { header: H, rows: [], rowsCount: 0 };
  var rows = [];
  for (var r = 1; r < V.length; r++) {
    var p = normalizePassportPlain8_(V[r][cP]);
    if (p && passSet.has(p)) rows.push(V[r]);
  }
  return { header: H, rows: rows, rowsCount: rows.length };
}

function _readStagingArticlesByPassports_(ss, passSet) {
  var sh = ss.getSheetByName('STAGING_ARTICLES');
  if (!sh || sh.getLastRow() < 2) return { header: [], rows: [], rowsCount: 0 };
  var V = sh.getDataRange().getValues(), H = V[0], cP = H.indexOf('Passeport');
  if (cP < 0) return { header: H, rows: [], rowsCount: 0 };
  var rows = [];
  for (var r = 1; r < V.length; r++) {
    var p = normalizePassportPlain8_(V[r][cP]);
    if (p && passSet.has(p)) rows.push(V[r]);
  }
  return { header: H, rows: rows, rowsCount: rows.length };
}

/* ---------------------------------
   PERF cache (params/mappings/membres)
---------------------------------- */

var __rulesPerfCache = null;

function _rulesPerfCacheBegin_(ss) {
  __rulesPerfCache = {
    params: _readParamsAsMap_(ss),             // map {key->value}
    mappings: _readArticlesMappingAsMap_(),    // impl existante ou à écrire si besoin
    membres: _readMembresGlobalAsMap_(ss)      // { passeport -> {PhotoExpireLe, CasierExpiré, ...} }
  };
}

function _rulesPerfCacheEnd_() { __rulesPerfCache = null; }

function _readParamsAsMap_(ss) {
  var sh = ss.getSheetByName('PARAMS'); if (!sh || sh.getLastRow() < 2) return {};
  var V = sh.getRange(2, 1, sh.getLastRow() - 1, 2).getValues(), m = {};
  for (var i = 0; i < V.length; i++) { m[String(V[i][0] || '')] = String(V[i][1] || ''); }
  return m;
}

function _readMembresGlobalAsMap_(ss) {
  var sh = ss.getSheetByName('MEMBRES_GLOBAL'); if (!sh || sh.getLastRow() < 2) return {};
  var V = sh.getDataRange().getValues(); var H = V[0]; var cP = H.indexOf('Passeport'); if (cP < 0) return {};
  var m = {}; for (var r = 1; r < V.length; r++) { var p = normalizePassportPlain8_(V[r][cP]); if (p) { m[p] = _rowToObj_(H, V[r]); } }
  return m;
}

function _rowToObj_(H, row) { var o = {}; for (var i = 0; i < H.length; i++) o[String(H[i] || '')] = row[i]; return o; }


/*************************************************
 * RULES ENGINE SWITCH (FAST vs LEGACY)
 *************************************************/
(function bootstrapRulesEngineSwitcher_(){
  try {
    if (typeof PARAM_KEYS === 'undefined') { this.PARAM_KEYS = {}; }
    if (!PARAM_KEYS.RULES_ENGINE) PARAM_KEYS.RULES_ENGINE = 'RULES_ENGINE';

    // Sauvegarde références LEGACY (celles définies plus haut dans ce fichier)
    var __runEvaluateRules_legacy__ = (typeof runEvaluateRules === 'function') ? runEvaluateRules : null;
    var __evaluateSeasonRulesIncr_legacy__ = (typeof evaluateSeasonRulesIncr === 'function') ? evaluateSeasonRulesIncr : null;

    function _rulesEngine_(){
      try {
        var ss = getSeasonSpreadsheet_(getSeasonId_());
        var v = String(readParam_(ss, PARAM_KEYS.RULES_ENGINE) || 'FAST').toUpperCase();
        return (v === 'LEGACY') ? 'LEGACY' : 'FAST';
      } catch(e){ return 'FAST'; }
    }

    // Redéfinition des points d’entrée publics
    this.runEvaluateRules = function(){
      if (_rulesEngine_()==='LEGACY' && __runEvaluateRules_legacy__) {
        return __runEvaluateRules_legacy__();
      }
      if (typeof runEvaluateRulesFast_Impl === 'function') {
        return runEvaluateRulesFast_Impl();
      }
      // Fallback si FAST absent
      return __runEvaluateRules_legacy__ ? __runEvaluateRules_legacy__() : { written:0, note:'no-impl' };
    };

    this.evaluateSeasonRulesIncr = function(touchedPassports, ss){
      if (_rulesEngine_()==='LEGACY' && __evaluateSeasonRulesIncr_legacy__) {
        return __evaluateSeasonRulesIncr_legacy__(touchedPassports, ss);
      }
      if (typeof evaluateSeasonRulesIncrFast_Impl === 'function') {
        return evaluateSeasonRulesIncrFast_Impl(touchedPassports, ss);
      }
      // Fallback si FAST absent
      return __evaluateSeasonRulesIncr_legacy__
        ? __evaluateSeasonRulesIncr_legacy__(touchedPassports, ss)
        : { written:0, note:'no-impl' };
    };
  } catch(e) {
    // en cas de souci, on ne casse rien
  }
})();


/***** fin server_rules.js *****/
