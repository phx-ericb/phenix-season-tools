/* ============================== server_flow.js =============================== */

function __ping_aug__() {
    var seasonId = getSeasonId_();
    var ok = (typeof runPostImportAugmentations_ === 'function');
    if (!ok) throw new Error('Hook not visible');
    runPostImportAugmentations_(seasonId, [], { isFull: true, isDryRun: false });
}



function runImportRulesExportsIncr() {
    var seasonId = getSeasonId_();
    var ss = getSeasonSpreadsheet_(seasonId);
    var ctx = startImportRun_({ seasonId: seasonId, source: 'dashboard-incr' });

    try {
        var imp = runImporterDonneesSaison();            // import via LIB
        var touched = _getTouchedPassportsArray_();      // passeports touchés

     // === (AVANT les règles) construire Ledger + Joueurs
try {
  var augOpts = { isFull:false, isDryRun:_boolParam_('DRY_RUN', false) };
  var did = false;

  if (LIB && typeof LIB.runPostImportAugmentations_ === 'function') {
    LIB.runPostImportAugmentations_(seasonId, touched, augOpts);
    appendImportLog_(ss, 'AUG_INCR_PRE_OK', JSON.stringify({ via:'LIB', count:touched.length||0 }));
    did = true;
  } else if (typeof runPostImportAugmentations_ === 'function') {
    runPostImportAugmentations_(seasonId, touched, augOpts);
    appendImportLog_(ss, 'AUG_INCR_PRE_OK', JSON.stringify({ via:'GLOBAL', count:touched.length||0 }));
    did = true;
  } else {
    // ---- Fallback direct: construire via fonctions unitaires de la lib
    var isDry = _boolParam_('DRY_RUN', false);
    var touchedSet = (function(a){
      if (!a) return new Set();
      if (a instanceof Set) return a;
      if (Array.isArray(a)) return new Set(a.map(function(x){return String(x).trim();}));
      var s=new Set(); try{Object.keys(a).forEach(function(k){ if(a[k]) s.add(String(k).trim()); });}catch(e){}
      return s;
    })(touched);

    if (!isDry) {
      var ledOn = String(readParam_(ss,'LEDGER_ENABLED')||'FALSE').toUpperCase()==='TRUE';
      var jOn   = String(readParam_(ss,'JOUEURS_ENABLED')||'FALSE').toUpperCase()==='TRUE';

      if (ledOn) {
        if (LIB && typeof LIB.updateAchatsLedgerForPassports_==='function') LIB.updateAchatsLedgerForPassports_(ss, touchedSet);
        else if (typeof updateAchatsLedgerForPassports_==='function') updateAchatsLedgerForPassports_(ss, touchedSet);
      }
      if (jOn) {
        if (LIB && typeof LIB.updateJoueursForPassports_==='function') LIB.updateJoueursForPassports_(ss, touchedSet);
        else if (typeof updateJoueursForPassports_==='function') updateJoueursForPassports_(ss, touchedSet);
      }
      appendImportLog_(ss, 'AUG_INCR_PRE_OK', JSON.stringify({ via:'FALLBACK', count:touchedSet.size||0 }));
      did = true;
    } else {
      appendImportLog_(ss, 'AUG_INCR_PRE_SKIP', 'DRY_RUN=TRUE');
      did = true;
    }
  }

  if (!did) appendImportLog_(ss, 'AUG_INCR_PRE_FAIL', 'No callable path');
} catch (eAugPre) {
  appendImportLog_(ss, 'AUG_INCR_PRE_FAIL', String(eAugPre));
}


        // RÈGLES (FAST ou LEGACY selon RULES_ENGINE)
        var rRules = null;
        if (touched.length) {
            rRules = evaluateSeasonRulesIncr(touched, ss);
            appendImportLog_(ss, 'RULES_INCR_DONE', rRules);
        } else {
            appendImportLog_(ss, 'RULES_INCR_SKIP', { reason: 'no-passports' });
        }

        // Exports incrémentaux habituels
        // Exports incrémentaux
        var combined = _boolParam_('RETRO_COMBINED_XLSX', false);
        var rExp = runRetroExportsIncr(touched, { combined: combined });

        // Mail pipeline APRÈS export (si désiré)
        try {
            var stage = String(readParam_(ss, 'MAIL_STAGE') || 'AFTER').trim().toUpperCase();
            if (stage === 'AFTER' && typeof runMailPipelineSelected_ === 'function') {
                runMailPipelineSelected_(ss, 'AFTER');
            }
        } catch (e) {
            appendImportLog_(ss, 'MAIL_PIPELINE_FAIL', String(e));
        }
        return { ok: true, import: imp, rules: rRules, exports: rExp };
    } catch (e) {
        appendImportLog_(ss, 'FLOW_INCR_FAIL', String(e));
        return { ok: false, error: String(e) };
    } finally {
        endImportRun_(ctx);
    }
}

function runImportRulesExportsFull() {
    var seasonId = getSeasonId_();
    var ss = getSeasonSpreadsheet_(seasonId);
    var ctx = startImportRun_({ seasonId: seasonId, source: 'dashboard-full' });

    try {
        var imp = runImporterDonneesSaison();

  // === (AVANT les règles) (re)construire Ledger + Joueurs
try {
  var augOpts = { isFull:true, isDryRun:_boolParam_('DRY_RUN', false) };
  var did = false;

  if (LIB && typeof LIB.runPostImportAugmentations_ === 'function') {
    LIB.runPostImportAugmentations_(seasonId, [], augOpts);
    appendImportLog_(ss, 'AUG_FULL_PRE_OK', JSON.stringify({ via:'LIB' }));
    did = true;
  } else if (typeof runPostImportAugmentations_ === 'function') {
    runPostImportAugmentations_(seasonId, [], augOpts);
    appendImportLog_(ss, 'AUG_FULL_PRE_OK', JSON.stringify({ via:'GLOBAL' }));
    did = true;
  } else {
    // ---- Fallback direct: construire via fonctions unitaires de la lib
    var isDry = _boolParam_('DRY_RUN', false);
    if (!isDry) {
      var ledOn = String(readParam_(ss,'LEDGER_ENABLED')||'FALSE').toUpperCase()==='TRUE';
      var jOn   = String(readParam_(ss,'JOUEURS_ENABLED')||'FALSE').toUpperCase()==='TRUE';

      if (ledOn) {
        if (LIB && typeof LIB.buildAchatsLedger_==='function') LIB.buildAchatsLedger_(ss);
        else if (typeof buildAchatsLedger_==='function') buildAchatsLedger_(ss);
      }
      if (jOn) {
        if (LIB && typeof LIB.buildJoueursIndex_==='function') LIB.buildJoueursIndex_(ss);
        else if (typeof buildJoueursIndex_==='function') buildJoueursIndex_(ss);
      }
      appendImportLog_(ss, 'AUG_FULL_PRE_OK', JSON.stringify({ via:'FALLBACK' }));
      did = true;
    } else {
      appendImportLog_(ss, 'AUG_FULL_PRE_SKIP', 'DRY_RUN=TRUE');
      did = true;
    }
  }
  if (!did) appendImportLog_(ss, 'AUG_FULL_PRE_FAIL', 'No callable path');
} catch (eAugPre) {
  appendImportLog_(ss, 'AUG_FULL_PRE_FAIL', String(eAugPre));
}



        // RÈGLES (FAST ou LEGACY selon RULES_ENGINE)
        var rFull = runEvaluateRules();          // FAST ou LEGACY selon RULES_ENGINE
        var mRes = runExportRetroMembres();     // FULL garanti
        var gRes = runExportRetroGroupes();     // FULL garanti

        // Mail pipeline APRÈS export
        try {
            var stage = String(readParam_(ss, 'MAIL_STAGE') || 'AFTER').trim().toUpperCase();
            if (stage === 'AFTER' && typeof runMailPipelineSelected_ === 'function') {
                runMailPipelineSelected_(ss, 'AFTER');
            }
        } catch (e) {
            appendImportLog_(ss, 'MAIL_PIPELINE_FAIL', String(e));
        }

        return { ok: true, import: imp, rules: rFull, membres: mRes, groupes: gRes };

    } catch (e) {
        appendImportLog_(ss, 'FLOW_FULL_FAIL', String(e));
        return { ok: false, error: String(e) };
    } finally {
        endImportRun_(ctx);
    }
}


function _boolParam_(key, defVal) {
    var v = String(readParamValue(key) || '').trim().toLowerCase();
    if (!v) return !!defVal;
    return v === '1' || v === 'true' || v === 'yes' || v === 'oui';
}